# Overview

This is a modern full-stack portfolio application built for K Sai Kiran, a cybersecurity expert and entrepreneur. The application showcases professional experience, entrepreneurial journey, and includes a contact form system. It's built with React on the frontend and Express.js on the backend, utilizing PostgreSQL for data persistence and featuring a modern, responsive design with animated components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Styling**: Tailwind CSS with custom color schemes and glass morphism effects
- **Animations**: Framer Motion for smooth page transitions and component animations
- **Forms**: React Hook Form with Zod validation for robust form handling

## Backend Architecture  
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Email**: Nodemailer for contact form email notifications
- **Storage**: In-memory storage implementation with interface for easy database migration
- **API Design**: RESTful API with structured error handling and request logging

## Build System & Development
- **Build Tool**: Vite for fast development and optimized production builds
- **Bundling**: ESBuild for server-side bundling
- **Development**: Hot module replacement and runtime error overlay for enhanced developer experience
- **TypeScript**: Strict type checking across frontend, backend, and shared schemas

## Data Layer
- **Schema Management**: Drizzle Kit for database migrations and schema management
- **Validation**: Zod schemas shared between frontend and backend for consistent data validation
- **Models**: User and Contact entities with proper TypeScript inference
- **Connection**: Neon Database serverless PostgreSQL for scalable data storage

## UI/UX Design Decisions
- **Design System**: New York style from shadcn/ui with custom color palette
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: Radix UI primitives ensure WCAG compliance
- **Performance**: Lazy loading, optimized animations, and efficient re-renders
- **Theme**: Professional blue and yellow color scheme with glass morphism effects

# External Dependencies

## Database & Infrastructure
- **Neon Database**: Serverless PostgreSQL database for scalable data storage
- **Drizzle ORM**: Type-safe database operations with automatic TypeScript inference

## UI & Animation Libraries  
- **Radix UI**: Headless UI primitives for accessible component foundations
- **Framer Motion**: Advanced animation library for smooth transitions and interactions
- **Lucide React**: Consistent icon library for modern UI elements

## Development & Build Tools
- **Vite**: Modern build tool with fast HMR and optimized production builds
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility

## Form & Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Schema validation library for runtime type checking
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## Email & Communication
- **Nodemailer**: Email sending functionality for contact form notifications
- **SMTP Configuration**: Support for Gmail and custom SMTP providers

## Development Experience
- **TypeScript**: Full-stack type safety with strict configuration
- **ESLint**: Code quality and consistency enforcement
- **Replit Integration**: Cartographer plugin and runtime error modal for cloud development