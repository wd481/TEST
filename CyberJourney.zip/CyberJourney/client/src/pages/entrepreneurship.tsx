import { motion } from "framer-motion";
import Timeline from "@/components/ui/timeline";
import AnimatedCard from "@/components/ui/animated-card";
import { Building, Users, TrendingUp, Award, Search, UserCheck, GraduationCap, Settings } from "lucide-react";

const Entrepreneurship = () => {
  const companyStats = [
    { value: "25+", label: "Clients Served" },
    { value: "$2M+", label: "Revenue Generated" },
    { value: "10+", label: "Team Members" },
    { value: "95%", label: "Client Satisfaction" },
  ];

  const growthTimeline = [
    {
      id: "foundation",
      title: "Company Foundation",
      company: "Hex Tech Solutions",
      period: "Q1 2022",
      description: "Launched Hex Tech Solutions with a vision to democratize cybersecurity for businesses of all sizes. Started with a core team of 3 cybersecurity experts and secured our first client within the first month.",
      imageUrl: "https://images.unsplash.com/photo-1664575602554-2087b04935a5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
      imageAlt: "Business strategy planning",
    },
    {
      id: "first-client",
      title: "First Major Client",
      company: "Enterprise Partnership",
      period: "Q3 2022",
      description: "Secured our first enterprise client, delivering comprehensive security audit and implementation services. This milestone validated our business model and established our reputation in the cybersecurity consulting space.",
      imageUrl: "https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
      imageAlt: "Business partnership handshake",
    },
    {
      id: "team-expansion",
      title: "Team Expansion",
      company: "Growth Phase",
      period: "Q1 2023",
      description: "Expanded team to 10+ cybersecurity experts, establishing ourselves as a leading regional consultancy. Implemented structured processes and obtained key industry certifications for the company.",
      imageUrl: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
      imageAlt: "Growing startup team",
    },
    {
      id: "market-leader",
      title: "Market Leadership",
      company: "Industry Recognition",
      period: "Q4 2023",
      description: "Achieved recognition as a leading cybersecurity consultancy in the region. Expanded service offerings to include compliance consulting, security training, and managed security services.",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      imageAlt: "Modern tech startup office",
    },
  ];

  const services = [
    {
      icon: <Search className="text-3xl text-primary-blue" />,
      title: "Security Audits",
      description: "Comprehensive security assessments",
      imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <UserCheck className="text-3xl text-accent-yellow" />,
      title: "Penetration Testing",
      description: "Ethical hacking services",
      imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <GraduationCap className="text-3xl text-primary-blue" />,
      title: "Security Training",
      description: "Employee awareness programs",
      imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <Settings className="text-3xl text-accent-yellow" />,
      title: "Consulting",
      description: "Strategic security guidance",
      imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
  ];

  const achievements = [
    {
      icon: <Award className="w-6 h-6" />,
      title: "Industry Recognition",
      description: "Featured in CyberSecurity Magazine as 'Rising Star in Cybersecurity'",
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Revenue Growth",
      description: "Achieved 300% year-over-year revenue growth in the first two years",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Team Excellence",
      description: "Built a team of certified professionals with 95% employee satisfaction",
    },
    {
      icon: <Building className="w-6 h-6" />,
      title: "Market Presence",
      description: "Established strong presence in 3 major metropolitan areas",
    },
  ];

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-blue-50 via-purple-50 to-yellow-50">
      {/* Header */}
      <section className="enhanced-bg py-20 relative overflow-hidden">
        {/* Enhanced Animated Background */}
        <div className="animated-bg-elements">
          {/* Large Floating Circles */}
          <motion.div
            animate={{
              x: [0, 200, 0],
              y: [0, -100, 0],
              scale: [1, 1.2, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              x: [0, -150, 0],
              y: [0, 120, 0],
              scale: [1, 0.8, 1],
              rotate: [0, -120, -360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-32 right-10 w-80 h-80 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 rounded-full blur-2xl"
          />
          
          {/* Medium Geometric Shapes */}
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-32 h-32 bg-gradient-to-r from-cyan-400/15 to-blue-400/15 rounded-2xl"
          />
          <motion.div
            animate={{
              rotate: [0, -360],
              x: [0, 50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute bottom-1/4 right-1/3 w-24 h-24 bg-gradient-to-r from-purple-400/15 to-pink-400/15 rounded-full"
          />
          
          {/* Small Floating Elements */}
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.2,
              }}
              className={`absolute w-2 h-2 bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-full`}
              style={{
                top: `${20 + (i * 7)}%`,
                left: `${10 + (i * 8)}%`,
              }}
            />
          ))}
          
          {/* Grid Pattern Overlay */}
          <div className="grid-pattern" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              <span className="gradient-text">Entrepreneurial Journey</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Building innovative cybersecurity solutions through Hex Tech Solutions
            </p>
          </motion.div>
        </div>
      </section>

      {/* Company Showcase */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              x: [0, 80, 0],
              y: [0, -60, 0],
              rotate: [0, 120, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-16 right-20 w-36 h-36 bg-gradient-to-r from-primary-blue/4 to-accent-yellow/4 rounded-full"
          />
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              y: [0, 40, 0],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-24 left-16 w-28 h-28 bg-gradient-to-r from-accent-yellow/3 to-primary-blue/3 rounded-2xl"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <AnimatedCard className="p-8 rounded-3xl">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary-blue to-accent-yellow rounded-2xl flex items-center justify-center mr-4">
                    <span className="text-white font-bold text-lg">HTS</span>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold gradient-text">Hex Tech Solutions</h2>
                    <p className="text-gray-600">Founded 2022</p>
                  </div>
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  A cutting-edge cybersecurity consultancy specializing in ethical hacking, penetration testing, 
                  and security architecture design for enterprises worldwide. We combine technical expertise 
                  with business acumen to deliver comprehensive security solutions.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {companyStats.map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="text-center p-4 bg-white/50 rounded-xl"
                      data-testid={`stat-company-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <div className={`text-2xl font-bold ${
                        index % 2 === 0 ? 'text-primary-blue' : 'text-accent-yellow'
                      }`}>
                        {stat.value}
                      </div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </motion.div>
                  ))}
                </div>
              </AnimatedCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="Modern tech startup office"
                className="rounded-3xl shadow-2xl w-full h-96 object-cover card-3d"
                data-testid="img-company-office"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Growth Timeline */}
      <section className="py-20 bg-bg-secondary relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="geometric-bg" />
        <div className="particle-field">
          {Array.from({ length: 10 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 8 + 6}px`,
                height: `${Math.random() * 8 + 6}px`,
                animationDelay: `${Math.random() * 20}s`,
                animationDuration: `${Math.random() * 15 + 20}s`,
              }}
            />
          ))}
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Company Growth Timeline</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From startup to industry leader - our journey of innovation and growth
            </p>
          </motion.div>

          <Timeline items={growthTimeline} />
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              rotate: [0, -360],
              x: [0, 40, 0],
            }}
            transition={{
              duration: 22,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-32 left-32 w-24 h-24 bg-gradient-to-r from-primary-blue/5 to-accent-yellow/5 rounded-3xl"
          />
          <motion.div
            animate={{
              y: [0, -50, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-40 right-24 w-32 h-32 bg-gradient-to-r from-accent-yellow/3 to-primary-blue/3 rounded-full"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Our Services</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive cybersecurity solutions tailored to your business needs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <AnimatedCard
                key={service.title}
                delay={index * 0.1}
                className="p-0 rounded-2xl overflow-hidden"
              >
                {service.imageUrl && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="relative h-40 overflow-hidden"
                  >
                    <img
                      src={service.imageUrl}
                      alt={service.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  </motion.div>
                )}
                <div className="p-4 text-center">
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="mb-4"
                  >
                    {service.icon}
                  </motion.div>
                  <h3 className="font-bold mb-2" data-testid={`text-service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{service.description}</p>
                </div>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-bg-secondary relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="geometric-bg" />
        <div className="particle-field">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 9 + 7}px`,
                height: `${Math.random() * 9 + 7}px`,
                animationDelay: `${Math.random() * 25}s`,
                animationDuration: `${Math.random() * 20 + 25}s`,
              }}
            />
          ))}
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Key Achievements</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Milestones that define our journey to success
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {achievements.map((achievement, index) => (
              <AnimatedCard
                key={achievement.title}
                delay={index * 0.15}
                className="p-8 rounded-2xl"
              >
                <div className="flex items-start space-x-4">
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.15 + 0.2 }}
                    viewport={{ once: true }}
                    className="w-12 h-12 bg-gradient-to-r from-primary-blue to-accent-yellow rounded-xl flex items-center justify-center text-white flex-shrink-0"
                  >
                    {achievement.icon}
                  </motion.div>
                  <div>
                    <h3 className="text-xl font-bold mb-2 text-gray-800">
                      {achievement.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {achievement.description}
                    </p>
                  </div>
                </div>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Entrepreneurship;
