import HeroSection from "@/components/layout/hero-section";
import ContactForm from "@/components/ui/contact-form";
import AnimatedCard from "@/components/ui/animated-card";
import { motion } from "framer-motion";
import { Shield, Mail, Phone, MapPin, Linkedin, Github, Twitter } from "lucide-react";

const Home = () => {
  const heroStats = [
    { value: "5+", label: "Years Experience" },
    { value: "100+", label: "Security Audits" },
    { value: "50+", label: "Clients Secured" },
  ];

  const contactInfo = [
    {
      icon: <Mail className="text-white" />,
      title: "Email",
      value: "saikiran.k@hextechsolutions.in",
      gradient: "from-primary-blue to-secondary-blue",
    },
    {
      icon: <Phone className="text-white" />,
      title: "Phone",
      value: "+91 9876543210",
      gradient: "from-accent-yellow to-light-yellow",
    },
    {
      icon: <MapPin className="text-white" />,
      title: "Location",
      value: "Hyderabad, India",
      gradient: "from-primary-blue to-accent-yellow",
    },
  ];

  const socialLinks = [
    {
      icon: <Linkedin />,
      href: "#",
      gradient: "from-primary-blue to-secondary-blue",
    },
    {
      icon: <Github />,
      href: "#",
      gradient: "from-gray-800 to-gray-600",
    },
    {
      icon: <Twitter />,
      href: "#",
      gradient: "from-blue-500 to-blue-400",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section with Enhanced Background */}
      <section className="relative min-h-screen overflow-hidden bg-gradient-to-br from-blue-50 via-purple-50 to-yellow-50">
        {/* Animated Background Graphics */}
        <div className="absolute inset-0 overflow-hidden">
          {/* Large Floating Circles */}
          <motion.div
            animate={{
              x: [0, 200, 0],
              y: [0, -100, 0],
              scale: [1, 1.2, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              x: [0, -150, 0],
              y: [0, 120, 0],
              scale: [1, 0.8, 1],
              rotate: [0, -120, -360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-32 right-10 w-80 h-80 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 rounded-full blur-2xl"
          />
          
          {/* Medium Geometric Shapes */}
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-32 h-32 bg-gradient-to-r from-cyan-400/15 to-blue-400/15 rounded-2xl"
          />
          <motion.div
            animate={{
              rotate: [0, -360],
              x: [0, 50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute bottom-1/4 right-1/3 w-24 h-24 bg-gradient-to-r from-purple-400/15 to-pink-400/15 rounded-full"
          />
          
          {/* Small Floating Elements */}
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.2,
              }}
              className={`absolute w-2 h-2 bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-full`}
              style={{
                top: `${20 + (i * 7)}%`,
                left: `${10 + (i * 8)}%`,
              }}
            />
          ))}
          
          {/* Grid Pattern Overlay */}
          <div className="absolute inset-0 opacity-5">
            <div className="w-full h-full" style={{
              backgroundImage: `radial-gradient(circle at 1px 1px, rgba(59, 130, 246, 0.3) 1px, transparent 0)`,
              backgroundSize: '40px 40px'
            }} />
          </div>
        </div>
        
        <HeroSection
          title="Cybersecurity"
          subtitle="Expert & Innovator"
          description="Ethical Hacker | Cybersecurity Specialist | Founder of Hex Tech Solutions"
          primaryAction={{
            label: "View My Work",
            href: "/professional",
            icon: <Shield className="w-4 h-4 mr-2" />,
          }}
          secondaryAction={{
            label: "Get In Touch",
            href: "#contact",
            icon: <Mail className="w-4 h-4 mr-2" />,
          }}
          stats={heroStats}
          imageUrl="https://images.unsplash.com/photo-1556075798-4825dfaaf498?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
          imageAlt="Professional cybersecurity expert at work"
        />
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 relative overflow-hidden">
        {/* Enhanced Animated Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Large Background Shapes */}
          <motion.div
            animate={{
              x: [0, 150, 0],
              y: [0, -80, 0],
              rotate: [0, 180, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute -top-32 -left-32 w-96 h-96 bg-gradient-to-r from-blue-400/8 to-purple-400/8 rounded-full blur-2xl"
          />
          <motion.div
            animate={{
              x: [0, -120, 0],
              y: [0, 100, 0],
              rotate: [0, -180, -360],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-20 -right-32 w-80 h-80 bg-gradient-to-r from-yellow-400/8 to-orange-400/8 rounded-full blur-xl"
          />
          
          {/* Medium Floating Elements */}
          <motion.div
            animate={{
              x: [0, 100, 0],
              y: [0, -50, 0],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-20 left-20 w-32 h-32 bg-gradient-to-r from-cyan-400/12 to-blue-400/12 rounded-3xl"
          />
          <motion.div
            animate={{
              x: [0, -80, 0],
              y: [0, 60, 0],
              rotate: [0, -180, -360],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-40 right-32 w-24 h-24 bg-gradient-to-r from-purple-400/12 to-pink-400/12 rounded-2xl"
          />
          <motion.div
            animate={{
              x: [0, 50, 0],
              y: [0, -80, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-32 left-1/4 w-20 h-20 bg-gradient-to-r from-green-400/12 to-teal-400/12 rounded-xl"
          />
          
          {/* Small Particles */}
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -15, 0],
                opacity: [0.2, 0.6, 0.2],
                rotate: [0, 360],
              }}
              transition={{
                duration: 4 + i,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.3,
              }}
              className={`absolute w-3 h-3 bg-gradient-to-r from-blue-500/25 to-purple-500/25 rounded-full`}
              style={{
                top: `${25 + (i * 8)}%`,
                right: `${15 + (i * 6)}%`,
              }}
            />
          ))}
          
          {/* Connecting Lines Animation */}
          <svg className="absolute inset-0 w-full h-full opacity-10">
            <motion.path
              d="M100,100 Q200,50 300,100 T500,100"
              stroke="url(#gradient)"
              strokeWidth="2"
              fill="none"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgb(59, 130, 246)" stopOpacity="0.3" />
                <stop offset="100%" stopColor="rgb(147, 51, 234)" stopOpacity="0.3" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Let's Connect</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ready to secure your digital future? Let's discuss how we can protect your business.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              {/* Contact Hero Image */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="mb-8 rounded-3xl overflow-hidden glass-morphism"
              >
                <img
                  src="https://images.unsplash.com/photo-1423666639041-f56000c27a9a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=600"
                  alt="Professional contact and communication"
                  className="w-full h-48 object-cover"
                />
              </motion.div>
              <ContactForm />
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              {contactInfo.map((info, index) => (
                <AnimatedCard key={info.title} delay={index * 0.1} className="p-6 rounded-2xl">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-r ${info.gradient} rounded-xl flex items-center justify-center mr-4`}>
                      {info.icon}
                    </div>
                    <div>
                      <h4 className="font-bold" data-testid={`text-${info.title.toLowerCase()}`}>
                        {info.title}
                      </h4>
                      <p className="text-gray-600">{info.value}</p>
                    </div>
                  </div>
                </AnimatedCard>
              ))}

              {/* Social Links */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
                className="flex space-x-4"
              >
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.href}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-12 h-12 bg-gradient-to-r ${social.gradient} rounded-xl flex items-center justify-center text-white transition-transform duration-300`}
                    data-testid={`link-social-${index}`}
                  >
                    {social.icon}
                  </motion.a>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-primary-blue to-accent-yellow rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">KSK</span>
                </div>
                <span className="text-xl font-bold">K Sai Kiran</span>
              </div>
              <p className="text-gray-400">
                Cybersecurity Expert & Founder of Hex Tech Solutions. Securing digital futures through innovative solutions.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="/" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Home
                  </a>
                </li>
                <li>
                  <a href="/professional" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Experience
                  </a>
                </li>
                <li>
                  <a href="/entrepreneurship" className="text-gray-400 hover:text-white transition-colors duration-300">
                    Entrepreneurship
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-4">Services</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Penetration Testing</li>
                <li className="text-gray-400">Security Audits</li>
                <li className="text-gray-400">Vulnerability Assessment</li>
                <li className="text-gray-400">Security Consulting</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              &copy; 2024 K Sai Kiran. All rights reserved. Built for AWS EC2 deployment.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
