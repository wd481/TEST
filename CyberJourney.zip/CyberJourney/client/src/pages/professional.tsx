import { motion } from "framer-motion";
import Timeline from "@/components/ui/timeline";
import AnimatedCard from "@/components/ui/animated-card";
import { Shield, Bug, Lock, Search, UserCheck, GraduationCap, Settings } from "lucide-react";

const Professional = () => {
  const experienceItems = [
    {
      id: "senior-consultant",
      title: "Senior Security Consultant",
      company: "CyberGuard Inc.",
      period: "2021 - Present",
      description: "Led comprehensive security audits for Fortune 500 companies, identifying critical vulnerabilities and implementing robust defense strategies. Managed a team of 5 security analysts and achieved a 98% client satisfaction rate.",
      imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Cybersecurity workspace",
    },
    {
      id: "ethical-hacker",
      title: "Ethical Hacker",
      company: "SecureNet Solutions",
      period: "2019 - 2021",
      description: "Conducted penetration testing and vulnerability assessments, helping organizations strengthen their security posture against emerging threats. Successfully identified and remediated over 500 security vulnerabilities across various industries.",
      imageUrl: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Ethical hacking workspace",
    },
    {
      id: "security-analyst",
      title: "Security Analyst",
      company: "TechShield Corp",
      period: "2017 - 2019",
      description: "Monitored security incidents, analyzed threat patterns, and developed incident response procedures for enterprise clients. Reduced average incident response time by 40% through process optimization and automation.",
      imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Security operations center",
    },
  ];

  const skills = [
    {
      icon: <Shield className="text-white text-2xl" />,
      title: "Penetration Testing",
      description: "Advanced penetration testing methodologies and vulnerability assessment techniques",
      gradient: "from-primary-blue to-secondary-blue",
      imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <Bug className="text-white text-2xl" />,
      title: "Threat Analysis",
      description: "Expert threat hunting and malware analysis with cutting-edge detection tools",
      gradient: "from-accent-yellow to-light-yellow",
      imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <Lock className="text-white text-2xl" />,
      title: "Security Architecture",
      description: "Design and implementation of enterprise-grade security architectures",
      gradient: "from-primary-blue to-accent-yellow",
      imageUrl: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <Search className="text-white text-2xl" />,
      title: "Vulnerability Assessment",
      description: "Comprehensive security assessments using industry-leading tools and methodologies",
      gradient: "from-secondary-blue to-primary-blue",
      imageUrl: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <UserCheck className="text-white text-2xl" />,
      title: "Risk Management",
      description: "Strategic risk assessment and mitigation planning for complex environments",
      gradient: "from-light-yellow to-accent-yellow",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
    {
      icon: <Settings className="text-white text-2xl" />,
      title: "Security Operations",
      description: "24/7 security monitoring, incident response, and security operations center management",
      gradient: "from-accent-yellow to-primary-blue",
      imageUrl: "https://images.unsplash.com/photo-1551808525-51a94da548ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400",
    },
  ];

  const certifications = [
    "Certified Ethical Hacker (CEH)",
    "Offensive Security Certified Professional (OSCP)",
    "Certified Information Security Manager (CISM)",
    "SANS GIAC Security Essentials (GSEC)",
    "Certified Information Systems Security Professional (CISSP)",
    "Certified Information Systems Auditor (CISA)",
  ];

  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-blue-50 via-purple-50 to-yellow-50">
      {/* Header */}
      <section className="enhanced-bg py-20 relative overflow-hidden">
        {/* Enhanced Animated Background */}
        <div className="animated-bg-elements">
          {/* Large Floating Circles */}
          <motion.div
            animate={{
              x: [0, 200, 0],
              y: [0, -100, 0],
              scale: [1, 1.2, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              x: [0, -150, 0],
              y: [0, 120, 0],
              scale: [1, 0.8, 1],
              rotate: [0, -120, -360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-32 right-10 w-80 h-80 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 rounded-full blur-2xl"
          />
          
          {/* Medium Geometric Shapes */}
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-32 h-32 bg-gradient-to-r from-cyan-400/15 to-blue-400/15 rounded-2xl"
          />
          <motion.div
            animate={{
              rotate: [0, -360],
              x: [0, 50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute bottom-1/4 right-1/3 w-24 h-24 bg-gradient-to-r from-purple-400/15 to-pink-400/15 rounded-full"
          />
          
          {/* Small Floating Elements */}
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.2,
              }}
              className={`absolute w-2 h-2 bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-full`}
              style={{
                top: `${20 + (i * 7)}%`,
                left: `${10 + (i * 8)}%`,
              }}
            />
          ))}
          
          {/* Grid Pattern Overlay */}
          <div className="grid-pattern" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              <span className="gradient-text">Professional Journey</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A decade of experience in cybersecurity, from ethical hacking to enterprise security solutions
            </p>
          </motion.div>
        </div>
      </section>

      {/* Experience Timeline */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="geometric-bg" />
        <div className="particle-field">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 8 + 6}px`,
                height: `${Math.random() * 8 + 6}px`,
                animationDelay: `${Math.random() * 20}s`,
                animationDuration: `${Math.random() * 15 + 20}s`,
              }}
            />
          ))}
        </div>
        {/* Additional floating elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              x: [0, 150, 0],
              y: [0, -100, 0],
              rotate: [0, 180, 360],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-32 left-1/4 w-32 h-32 bg-gradient-to-r from-primary-blue/4 to-accent-yellow/4 rounded-full"
          />
          <motion.div
            animate={{
              x: [0, -120, 0],
              y: [0, 80, 0],
              rotate: [0, -90, 0],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-1/4 right-1/3 w-24 h-24 bg-gradient-to-r from-accent-yellow/5 to-primary-blue/5 rounded-2xl"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <Timeline items={experienceItems} />
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20 bg-bg-secondary relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              rotate: [0, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-10 right-10 w-32 h-32 bg-gradient-to-r from-primary-blue/5 to-accent-yellow/5 rounded-full"
          />
          <motion.div
            animate={{
              y: [0, -30, 0],
              x: [0, 20, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-20 left-10 w-24 h-24 bg-gradient-to-r from-accent-yellow/4 to-primary-blue/4 rounded-2xl"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Core Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Specialized skills and technologies that drive cybersecurity excellence
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <AnimatedCard
                key={skill.title}
                delay={index * 0.1}
                className="p-0 rounded-2xl overflow-hidden"
              >
                {skill.imageUrl && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="relative h-48 overflow-hidden"
                  >
                    <img
                      src={skill.imageUrl}
                      alt={skill.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  </motion.div>
                )}
                <div className="p-6 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.1 + 0.2 }}
                    viewport={{ once: true }}
                    className={`w-16 h-16 bg-gradient-to-r ${skill.gradient} rounded-2xl mx-auto mb-4 flex items-center justify-center`}
                  >
                    {skill.icon}
                  </motion.div>
                  <h3 className="text-xl font-bold mb-3" data-testid={`text-skill-${skill.title.toLowerCase().replace(/\s+/g, '-')}`}>
                    {skill.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">{skill.description}</p>
                </div>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="geometric-bg" />
        <div className="particle-field">
          {Array.from({ length: 10 }).map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 7 + 5}px`,
                height: `${Math.random() * 7 + 5}px`,
                animationDelay: `${Math.random() * 18}s`,
                animationDuration: `${Math.random() * 12 + 18}s`,
              }}
            />
          ))}
        </div>
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              x: [0, 60, 0],
              y: [0, -40, 0],
              rotate: [0, 90, 0],
            }}
            transition={{
              duration: 14,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute top-1/4 left-1/4 w-28 h-28 bg-gradient-to-r from-primary-blue/3 to-accent-yellow/3 rounded-3xl"
          />
          <motion.div
            animate={{
              scale: [1, 1.3, 1],
              rotate: [0, -45, 0],
            }}
            transition={{
              duration: 16,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute bottom-1/3 right-1/4 w-20 h-20 bg-gradient-to-r from-accent-yellow/4 to-primary-blue/4 rounded-full"
          />
          <motion.div
            animate={{
              x: [0, 100, 0],
              y: [0, -60, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear",
            }}
            className="absolute top-1/2 right-10 w-36 h-36 bg-gradient-to-r from-primary-blue/2 to-accent-yellow/2 rounded-full"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              <span className="gradient-text">Certifications & Qualifications</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Industry-recognized certifications demonstrating expertise and commitment to excellence
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert, index) => (
              <AnimatedCard
                key={cert}
                delay={index * 0.1}
                className="p-6 rounded-xl text-center"
                hover3d={false}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-center justify-center mb-4"
                >
                  <GraduationCap className="w-8 h-8 text-primary-blue mr-3" />
                  <span className="font-semibold text-gray-800">{cert}</span>
                </motion.div>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Professional;
