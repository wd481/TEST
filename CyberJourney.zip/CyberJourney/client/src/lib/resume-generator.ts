import { jsPDF } from 'jspdf';

export const generateResumePDF = async () => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  let yPosition = margin;

  // Colors
  const primaryBlue = [37, 99, 235]; // RGB for primary-blue
  const accentYellow = [245, 158, 11]; // RGB for accent-yellow

  // Header
  doc.setFillColor(...primaryBlue);
  doc.rect(0, 0, pageWidth, 60, 'F');

  // Name and Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('K SAI KIRAN', margin, 25);

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text('Cybersecurity Expert & Entrepreneur', margin, 35);
  doc.text('Founder, Hex Tech Solutions', margin, 45);

  // Contact Info
  doc.setFontSize(10);
  doc.text('kiran@hextechsolutions.com | +91 9876543210 | Hyderabad, India', margin, 55);

  yPosition = 80;

  // Reset text color for body
  doc.setTextColor(0, 0, 0);

  // Professional Summary
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryBlue);
  doc.text('PROFESSIONAL SUMMARY', margin, yPosition);
  yPosition += 10;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  const summary = 'Seasoned cybersecurity expert with 5+ years of experience in ethical hacking, penetration testing, and security architecture. Founder of Hex Tech Solutions, specializing in comprehensive security audits and consulting for Fortune 500 companies. Proven track record of identifying and remediating critical vulnerabilities while building and leading high-performing security teams.';
  
  const summaryLines = doc.splitTextToSize(summary, pageWidth - 2 * margin);
  doc.text(summaryLines, margin, yPosition);
  yPosition += summaryLines.length * 5 + 10;

  // Experience
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryBlue);
  doc.text('PROFESSIONAL EXPERIENCE', margin, yPosition);
  yPosition += 15;

  const experiences = [
    {
      title: 'Senior Security Consultant',
      company: 'CyberGuard Inc.',
      period: '2021 - Present',
      description: '• Led comprehensive security audits for Fortune 500 companies\n• Managed team of 5 security analysts with 98% client satisfaction rate\n• Implemented robust defense strategies and incident response procedures'
    },
    {
      title: 'Ethical Hacker',
      company: 'SecureNet Solutions',
      period: '2019 - 2021',
      description: '• Conducted penetration testing and vulnerability assessments\n• Successfully identified and remediated 500+ security vulnerabilities\n• Developed automated testing frameworks and security tools'
    },
    {
      title: 'Security Analyst',
      company: 'TechShield Corp',
      period: '2017 - 2019',
      description: '• Monitored security incidents and analyzed threat patterns\n• Reduced incident response time by 40% through process optimization\n• Developed incident response procedures for enterprise clients'
    }
  ];

  experiences.forEach(exp => {
    if (yPosition > 250) {
      doc.addPage();
      yPosition = margin;
    }

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text(exp.title, margin, yPosition);
    
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(...accentYellow);
    doc.text(`${exp.company} | ${exp.period}`, margin, yPosition + 7);
    
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    const descLines = doc.splitTextToSize(exp.description, pageWidth - 2 * margin);
    doc.text(descLines, margin, yPosition + 15);
    yPosition += descLines.length * 4 + 20;
  });

  // Entrepreneurship
  if (yPosition > 200) {
    doc.addPage();
    yPosition = margin;
  }

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryBlue);
  doc.text('ENTREPRENEURSHIP', margin, yPosition);
  yPosition += 15;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('Founder & CEO - Hex Tech Solutions', margin, yPosition);
  
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...accentYellow);
  doc.text('2022 - Present', margin, yPosition + 7);
  
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  const entrepreneurship = '• Founded cybersecurity consultancy specializing in ethical hacking and penetration testing\n• Grew company to 25+ clients with $2M+ revenue in first two years\n• Built team of 10+ certified cybersecurity professionals\n• Achieved 95% client satisfaction and 300% year-over-year growth';
  const entLines = doc.splitTextToSize(entrepreneurship, pageWidth - 2 * margin);
  doc.text(entLines, margin, yPosition + 15);
  yPosition += entLines.length * 4 + 20;

  // Skills
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryBlue);
  doc.text('CORE SKILLS', margin, yPosition);
  yPosition += 10;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  const skills = 'Penetration Testing • Ethical Hacking • Vulnerability Assessment • Security Architecture • Threat Analysis • Risk Management • Incident Response • Compliance Auditing • Team Leadership • Business Development';
  const skillLines = doc.splitTextToSize(skills, pageWidth - 2 * margin);
  doc.text(skillLines, margin, yPosition);
  yPosition += skillLines.length * 5 + 15;

  // Certifications
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryBlue);
  doc.text('CERTIFICATIONS', margin, yPosition);
  yPosition += 10;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  const certs = [
    'Certified Ethical Hacker (CEH)',
    'Offensive Security Certified Professional (OSCP)',
    'Certified Information Security Manager (CISM)',
    'SANS GIAC Security Essentials (GSEC)',
    'Certified Information Systems Security Professional (CISSP)',
    'Certified Information Systems Auditor (CISA)'
  ];

  certs.forEach(cert => {
    doc.text(`• ${cert}`, margin, yPosition);
    yPosition += 6;
  });

  // Save the PDF
  doc.save('K-Sai-Kiran-Resume.pdf');
};
