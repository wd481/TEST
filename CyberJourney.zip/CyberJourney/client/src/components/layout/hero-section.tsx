import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Shield, Mail, ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface HeroSectionProps {
  title: string;
  subtitle: string;
  description: string;
  primaryAction?: {
    label: string;
    href: string;
    icon?: React.ReactNode;
  };
  secondaryAction?: {
    label: string;
    href: string;
    icon?: React.ReactNode;
  };
  stats?: Array<{
    value: string;
    label: string;
  }>;
  imageUrl?: string;
  imageAlt?: string;
}

const HeroSection = ({
  title,
  subtitle,
  description,
  primaryAction,
  secondaryAction,
  stats,
  imageUrl,
  imageAlt,
}: HeroSectionProps) => {
  return (
    <div className="relative z-10 min-h-screen flex items-center justify-center pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="animate-slide-up"
          >
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-5xl lg:text-6xl font-bold mb-6"
              data-testid="text-hero-title"
            >
              <span className="gradient-text">{title}</span>
              <br />
              {subtitle}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-xl text-gray-600 mb-8 leading-relaxed"
              data-testid="text-hero-description"
            >
              {description}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              {primaryAction && (
                <Link href={primaryAction.href}>
                  <Button
                    size="lg"
                    className="btn-3d bg-gradient-to-r from-primary-blue to-secondary-blue text-white hover:shadow-2xl"
                    data-testid={`button-${primaryAction.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {primaryAction.icon}
                    {primaryAction.label}
                  </Button>
                </Link>
              )}

              {secondaryAction && (
                secondaryAction.href.startsWith('#') ? (
                  <Button
                    size="lg"
                    variant="outline"
                    className="btn-3d glass-morphism text-primary-blue hover:bg-white/40"
                    data-testid={`button-${secondaryAction.label.toLowerCase().replace(/\s+/g, '-')}`}
                    onClick={() => {
                      const element = document.querySelector(secondaryAction.href);
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    {secondaryAction.icon}
                    {secondaryAction.label}
                  </Button>
                ) : (
                  <Link href={secondaryAction.href}>
                    <Button
                      size="lg"
                      variant="outline"
                      className="btn-3d glass-morphism text-primary-blue hover:bg-white/40"
                      data-testid={`button-${secondaryAction.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {secondaryAction.icon}
                      {secondaryAction.label}
                    </Button>
                  </Link>
                )
              )}
            </motion.div>

            {/* Stats */}
            {stats && stats.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                className="grid grid-cols-3 gap-6 mt-12"
              >
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: 1 + index * 0.1 }}
                    className="text-center"
                    data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <div className="text-3xl font-bold text-primary-blue">
                      {stat.value}
                    </div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative animate-float"
          >
            {/* Image Container */}
            <div className="relative z-10">
              <motion.div
                whileHover={{ scale: 1.05, rotateY: -5 }}
                transition={{ duration: 0.4 }}
                className="w-80 h-80 mx-auto rounded-3xl overflow-hidden shadow-2xl card-3d"
              >
                {imageUrl ? (
                  <img
                    src={imageUrl}
                    alt={imageAlt || "Professional photo"}
                    className="w-full h-full object-cover"
                    data-testid="img-hero-photo"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-primary-blue/20 to-accent-yellow/20 flex items-center justify-center">
                    <div className="text-center">
                      <Shield className="w-20 h-20 text-primary-blue/60 mx-auto mb-4" />
                      <p className="text-gray-500 font-medium">
                        Professional Photo Placeholder
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>

            {/* Floating Elements */}
            <motion.div
              animate={{
                y: [0, -20, 0],
                rotate: [0, 5, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-r from-accent-yellow to-light-yellow rounded-2xl animate-pulse-slow opacity-80"
            />
            <motion.div
              animate={{
                y: [0, 15, 0],
                rotate: [0, -5, 0],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1,
              }}
              className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-r from-primary-blue to-secondary-blue rounded-xl animate-float opacity-60"
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
