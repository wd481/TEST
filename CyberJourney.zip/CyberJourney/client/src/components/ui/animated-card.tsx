import { motion } from "framer-motion";
import { ReactNode } from "react";

interface AnimatedCardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  hover3d?: boolean;
  glassEffect?: boolean;
}

const AnimatedCard = ({
  children,
  className = "",
  delay = 0,
  hover3d = true,
  glassEffect = true,
}: AnimatedCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      whileHover={
        hover3d
          ? {
              scale: 1.05,
              rotateY: -5,
              translateZ: 50,
            }
          : { scale: 1.02 }
      }
      className={`
        ${glassEffect ? "glass-morphism" : "bg-white shadow-lg"}
        ${hover3d ? "card-3d" : ""}
        transition-all duration-400 cursor-pointer
        ${className}
      `}
    >
      {children}
    </motion.div>
  );
};

export default AnimatedCard;
