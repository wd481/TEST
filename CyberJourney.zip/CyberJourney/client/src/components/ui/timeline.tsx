import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

export interface TimelineItem {
  id: string;
  title: string;
  company: string;
  period: string;
  description: string;
  imageUrl?: string;
  imageAlt?: string;
  side?: "left" | "right";
}

interface TimelineProps {
  items: TimelineItem[];
  className?: string;
}

const TimelineItemComponent = ({ item, index }: { item: TimelineItem; index: number }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const isEven = index % 2 === 0;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="relative mb-12"
      data-testid={`timeline-item-${item.id}`}
    >
      <div className="flex items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : { scale: 0 }}
          transition={{ duration: 0.4, delay: index * 0.2 + 0.3 }}
          className={`w-4 h-4 rounded-full absolute left-1/2 transform -translate-x-1/2 z-10 ${
            isEven ? "bg-primary-blue" : "bg-accent-yellow"
          }`}
        />
      </div>

      <div className="grid md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, x: isEven ? -50 : 50 }}
          animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: isEven ? -50 : 50 }}
          transition={{ duration: 0.6, delay: index * 0.2 + 0.4 }}
          className={isEven ? "md:text-right" : "md:order-last"}
        >
          <div className="glass-morphism p-6 rounded-2xl card-3d">
            <h3 className={`text-xl font-bold mb-2 ${
              isEven ? "text-primary-blue" : "text-accent-yellow"
            }`}>
              {item.title}
            </h3>
            <p className="text-gray-600 mb-2 font-medium">
              {item.company} | {item.period}
            </p>
            <p className="text-gray-700 leading-relaxed">{item.description}</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: isEven ? 50 : -50 }}
          animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: isEven ? 50 : -50 }}
          transition={{ duration: 0.6, delay: index * 0.2 + 0.6 }}
          className={isEven ? "" : "md:order-first"}
        >
          {item.imageUrl ? (
            <motion.img
              whileHover={{ scale: 1.05, rotateY: isEven ? -3 : 3 }}
              transition={{ duration: 0.3 }}
              src={item.imageUrl}
              alt={item.imageAlt || item.title}
              className="rounded-2xl shadow-lg w-full h-64 object-cover card-3d"
              data-testid={`img-timeline-${item.id}`}
            />
          ) : (
            <motion.div
              whileHover={{ scale: 1.05, rotateY: isEven ? -3 : 3 }}
              transition={{ duration: 0.3 }}
              className="rounded-2xl shadow-lg w-full h-64 bg-gradient-to-br from-primary-blue/10 to-accent-yellow/10 card-3d flex items-center justify-center"
            >
              <p className="text-gray-500 font-medium">Image Placeholder</p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
};

const Timeline = ({ items, className = "" }: TimelineProps) => {
  return (
    <div className={`relative max-w-4xl mx-auto ${className}`}>
      {/* Timeline Line */}
      <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full timeline-line" />

      {/* Timeline Items */}
      {items.map((item, index) => (
        <TimelineItemComponent key={item.id} item={item} index={index} />
      ))}
    </div>
  );
};

export default Timeline;
