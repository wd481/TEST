# Complete AWS EC2 Ubuntu 22.04 Deployment Guide
## K Sai Kiran Portfolio Website

This comprehensive guide covers every step needed to deploy your portfolio website on AWS EC2 Ubuntu 22.04 server.

## Prerequisites
- AWS Account with EC2 access
- Domain name (optional but recommended)
- Email account for SMTP configuration

---

## Part 1: AWS EC2 Server Setup

### Step 1: Launch EC2 Instance

1. **Login to AWS Console**
   - Go to https://aws.amazon.com
   - Sign in to your AWS Console
   - Navigate to EC2 service

2. **Launch New Instance**
   - Click "Launch Instance"
   - **Name**: `portfolio-server`
   - **Application and OS Images**: Ubuntu Server 22.04 LTS (HVM), SSD Volume Type
   - **Instance Type**: t2.micro (free tier) or t3.small (recommended for production)
   - **Key Pair**: Create new or select existing key pair for SSH access
   - **Network Settings**:
     - Create security group
     - Allow SSH (port 22) from your IP
     - Allow HTTP (port 80) from 0.0.0.0/0
     - Allow HTTPS (port 443) from 0.0.0.0/0
     - Allow Custom TCP (port 5000) from 0.0.0.0/0 for development
   - **Storage**: 20 GB gp3 (minimum recommended)
   - Launch Instance

3. **Allocate Elastic IP (Recommended)**
   - Go to EC2 → Elastic IPs
   - Allocate new Elastic IP address
   - Associate with your instance

### Step 2: Connect to Server

```bash
# Replace with your key file and public IP
chmod 400 your-key.pem
ssh -i your-key.pem ubuntu@YOUR_ELASTIC_IP
```

---

## Part 2: Server Environment Setup

### Step 3: Update System

```bash
# Update package lists
sudo apt update && sudo apt upgrade -y

# Install essential packages
sudo apt install -y curl wget git unzip software-properties-common
```

### Step 4: Install Node.js

```bash
# Install Node.js 20.x (LTS)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version  # Should show v20.x.x
npm --version   # Should show 10.x.x
```

### Step 5: Install PM2 (Process Manager)

```bash
# Install PM2 globally
sudo npm install -y pm2@latest -g

# Setup PM2 startup script
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u ubuntu --hp /home/ubuntu
```

### Step 6: Install Nginx (Reverse Proxy)

```bash
# Install Nginx
sudo apt install -y nginx

# Start and enable Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Check status
sudo systemctl status nginx
```

### Step 7: Setup Firewall

```bash
# Configure UFW firewall
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw allow 5000  # For development
sudo ufw --force enable

# Check status
sudo ufw status
```

---

## Part 3: Application Deployment

### Step 8: Clone and Setup Application

```bash
# Create application directory
sudo mkdir -p /var/www/portfolio
sudo chown ubuntu:ubuntu /var/www/portfolio
cd /var/www/portfolio

# Clone your repository (replace with your repo URL)
git clone https://github.com/yourusername/portfolio.git .
# OR upload your files manually

# Install dependencies
npm install

# Install TypeScript globally if needed
sudo npm install -g typescript tsx
```

### Step 9: Build Application

```bash
# Build the application
npm run build

# Test the application locally
npm run dev
# Press Ctrl+C after confirming it works
```

### Step 10: Environment Configuration

```bash
# Create production environment file
nano .env.production

# Add the following content (replace with your actual values):
NODE_ENV=production
PORT=5000
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
CONTACT_EMAIL=saikiran.k@hextechsolutions.in
```

### Step 11: Setup Gmail SMTP (Email Configuration)

#### Enable 2-Factor Authentication
1. Go to Google Account settings
2. Security → 2-Step Verification → Turn ON

#### Generate App Password
1. Google Account → Security → 2-Step Verification
2. At bottom, click "App passwords"
3. Select "Mail" and "Other (custom name)"
4. Enter "Portfolio Website"
5. Copy the 16-character password
6. Use this password as `SMTP_PASS` in .env.production

---

## Part 4: Production Configuration

### Step 12: Create Production Start Script

```bash
# Create production script
nano start-production.js

# Add this content:
const { spawn } = require('child_process');
const path = require('path');

// Set production environment
process.env.NODE_ENV = 'production';

// Load environment variables from .env.production
require('dotenv').config({ path: '.env.production' });

// Start the server
const serverProcess = spawn('tsx', ['server/index.ts'], {
  stdio: 'inherit',
  env: { ...process.env }
});

serverProcess.on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

process.on('SIGINT', () => {
  serverProcess.kill('SIGINT');
});

process.on('SIGTERM', () => {
  serverProcess.kill('SIGTERM');
});
```

### Step 13: Configure PM2

```bash
# Create PM2 ecosystem file
nano ecosystem.config.js

# Add this content:
module.exports = {
  apps: [{
    name: 'portfolio',
    script: 'start-production.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    max_memory_restart: '500M'
  }]
};

# Create logs directory
mkdir -p logs

# Start application with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Check status
pm2 status
pm2 logs portfolio
```

### Step 14: Configure Nginx Reverse Proxy

```bash
# Create Nginx site configuration
sudo nano /etc/nginx/sites-available/portfolio

# Add this content (replace YOUR_DOMAIN with your domain or IP):
server {
    listen 80;
    server_name YOUR_DOMAIN_OR_IP;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Static file caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

# Enable the site
sudo ln -s /etc/nginx/sites-available/portfolio /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

## Part 5: SSL Certificate Setup (Let's Encrypt)

### Step 15: Install Certbot

```bash
# Install snapd
sudo apt install -y snapd

# Install certbot
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot

# Link certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot
```

### Step 16: Obtain SSL Certificate

```bash
# Stop Nginx temporarily
sudo systemctl stop nginx

# Obtain certificate (replace with your domain)
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com

# Or use webroot method if site is already running
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Start Nginx
sudo systemctl start nginx

# Test automatic renewal
sudo certbot renew --dry-run
```

---

## Part 6: Database Setup (Optional - if using PostgreSQL)

### Step 17: Install PostgreSQL

```bash
# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql
CREATE DATABASE portfolio;
CREATE USER portfolio_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE portfolio TO portfolio_user;
\q

# Update environment file
echo "DATABASE_URL=postgresql://portfolio_user:your_secure_password@localhost:5432/portfolio" >> .env.production
```

---

## Part 7: Monitoring and Maintenance

### Step 18: Setup Log Rotation

```bash
# Create logrotate configuration
sudo nano /etc/logrotate.d/portfolio

# Add this content:
/var/www/portfolio/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 ubuntu ubuntu
    postrotate
        pm2 reload portfolio
    endscript
}
```

### Step 19: Setup Monitoring Script

```bash
# Create monitoring script
nano monitor.sh

# Add this content:
#!/bin/bash
echo "=== Portfolio Application Status ==="
echo "Date: $(date)"
echo ""
echo "=== PM2 Status ==="
pm2 status
echo ""
echo "=== Nginx Status ==="
sudo systemctl status nginx --no-pager
echo ""
echo "=== Disk Usage ==="
df -h /
echo ""
echo "=== Memory Usage ==="
free -h
echo ""
echo "=== Application Logs (last 20 lines) ==="
tail -20 /var/www/portfolio/logs/combined.log

# Make executable
chmod +x monitor.sh
```

### Step 20: Setup Automatic Updates

```bash
# Create update script
nano update.sh

# Add this content:
#!/bin/bash
cd /var/www/portfolio

echo "Pulling latest changes..."
git pull origin main

echo "Installing dependencies..."
npm install

echo "Building application..."
npm run build

echo "Restarting application..."
pm2 restart portfolio

echo "Application updated successfully!"

# Make executable
chmod +x update.sh
```

---

## Part 8: Security Hardening

### Step 21: Configure SSH Security

```bash
# Edit SSH configuration
sudo nano /etc/ssh/sshd_config

# Update these settings:
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
Protocol 2
ClientAliveInterval 300
ClientAliveCountMax 2

# Restart SSH
sudo systemctl restart ssh
```

### Step 22: Install Fail2Ban

```bash
# Install fail2ban
sudo apt install -y fail2ban

# Create configuration
sudo nano /etc/fail2ban/jail.local

# Add this content:
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

# Start fail2ban
sudo systemctl start fail2ban
sudo systemctl enable fail2ban
```

---

## Part 9: Final Verification

### Step 23: Complete Testing

```bash
# Check all services
sudo systemctl status nginx
sudo systemctl status postgresql  # if using database
pm2 status

# Test website
curl -I http://YOUR_DOMAIN_OR_IP
curl -I https://YOUR_DOMAIN_OR_IP  # if SSL enabled

# Test email functionality
# Visit your website and submit contact form

# Check logs
pm2 logs portfolio
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Step 24: Performance Optimization

```bash
# Enable Nginx caching
sudo nano /etc/nginx/nginx.conf

# Add inside http block:
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=app_cache:10m max_size=1g inactive=60m use_temp_path=off;

# Create cache directory
sudo mkdir -p /var/cache/nginx
sudo chown www-data:www-data /var/cache/nginx

# Restart Nginx
sudo systemctl restart nginx
```

---

## Backup and Recovery

### Automated Backup Script

```bash
# Create backup script
nano backup.sh

# Add this content:
#!/bin/bash
BACKUP_DIR="/home/ubuntu/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup application files
tar -czf "$BACKUP_DIR/portfolio_$DATE.tar.gz" /var/www/portfolio

# Backup database (if using PostgreSQL)
sudo -u postgres pg_dump portfolio > "$BACKUP_DIR/portfolio_db_$DATE.sql"

# Remove backups older than 7 days
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete

echo "Backup completed: $DATE"

# Make executable
chmod +x backup.sh

# Add to crontab for daily backups
(crontab -l 2>/dev/null; echo "0 2 * * * /home/ubuntu/backup.sh") | crontab -
```

---

## Troubleshooting Common Issues

### Application Won't Start
```bash
# Check logs
pm2 logs portfolio
cat /var/www/portfolio/logs/err.log

# Check permissions
ls -la /var/www/portfolio
sudo chown -R ubuntu:ubuntu /var/www/portfolio
```

### Email Not Working
```bash
# Test SMTP connection
telnet smtp.gmail.com 587

# Check environment variables
cat .env.production

# Verify Gmail app password is correct
```

### SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificate
sudo certbot renew

# Check Nginx configuration
sudo nginx -t
```

### High Memory Usage
```bash
# Check memory usage
free -h
pm2 monit

# Restart application if needed
pm2 restart portfolio
```

---

## Maintenance Commands

```bash
# Update application
cd /var/www/portfolio && ./update.sh

# Restart services
pm2 restart portfolio
sudo systemctl restart nginx

# View logs
pm2 logs portfolio --lines 100
sudo tail -f /var/log/nginx/error.log

# Monitor resources
pm2 monit
htop

# Check security
sudo fail2ban-client status
sudo ufw status

# Database maintenance (if using PostgreSQL)
sudo -u postgres psql -c "VACUUM ANALYZE;"
```

---

## Success Verification Checklist

- [ ] Website loads successfully at your domain/IP
- [ ] Contact form sends emails to saikiran.k@hextechsolutions.in
- [ ] Resume download functionality works
- [ ] All images display correctly
- [ ] SSL certificate is active (if configured)
- [ ] PM2 shows application running
- [ ] Nginx is serving content properly
- [ ] Logs are being generated correctly
- [ ] Firewall is configured properly
- [ ] Automatic backups are working

---

## Cost Optimization Tips

1. **Use t3.micro or t3.small** for small websites
2. **Setup CloudWatch alarms** for resource monitoring
3. **Use Elastic IP** to avoid IP changes
4. **Regular backups** to S3 for data safety
5. **Monitor bandwidth usage** to avoid overage charges

---

Your portfolio website is now fully deployed on AWS EC2 Ubuntu 22.04 with production-ready configuration, SSL security, email functionality, and automated monitoring!

**Support**: If you encounter any issues, check the logs and troubleshooting section above.