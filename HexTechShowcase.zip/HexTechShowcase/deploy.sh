
#!/bin/bash

# AWS EC2 Deployment Script for Portfolio Website
echo "🚀 Starting deployment process..."

# Exit on any error
set -e

# Create logs directory
mkdir -p logs

# Load environment variables
if [ -f .env.production ]; then
    export $(cat .env.production | grep -v '#' | awk '/=/ {print $1}')
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --only=production

# Install dev dependencies for build
npm install --only=dev

# Build frontend
echo "🏗️  Building React frontend..."
npm run build

# Check if build was successful
if [ ! -d "dist/public" ]; then
    echo "❌ Frontend build failed!"
    exit 1
fi

echo "✅ Frontend built successfully"

# Create production directories
sudo mkdir -p /var/www/portfolio
sudo chown -R $USER:$USER /var/www/portfolio

# Copy built files
echo "📁 Copying application files..."
cp -r dist /var/www/portfolio/
cp -r node_modules /var/www/portfolio/
cp package.json /var/www/portfolio/
cp ecosystem.config.js /var/www/portfolio/
cp .env.production /var/www/portfolio/

# Create logs directory in production location
mkdir -p /var/www/portfolio/logs

# Change to production directory
cd /var/www/portfolio

# Stop existing application
echo "🛑 Stopping existing application..."
pm2 delete portfolio-api 2>/dev/null || true

# Start application with PM2
echo "🔧 Starting application with PM2..."
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 startup script
pm2 startup

echo "✅ Deployment completed successfully!"
echo "📊 Application status:"
pm2 status

echo ""
echo "🌐 Your application is now running!"
echo "API: http://localhost:5000"
echo "Frontend: Served via Nginx"
echo ""
echo "📝 Next steps:"
echo "1. Configure Nginx reverse proxy"
echo "2. Set up SSL with Let's Encrypt"  
echo "3. Configure your domain DNS"
echo ""
echo "📚 Check deploy-aws.md for detailed instructions"
