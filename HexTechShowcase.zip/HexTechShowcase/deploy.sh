
#!/bin/bash

# AWS EC2 Deployment Script for Portfolio Website
echo "🚀 Starting deployment process..."

# Exit on any error
set -e

# Create logs directory
mkdir -p logs

# Load environment variables
if [ -f .env.production ]; then
    export $(cat .env.production | grep -v '#' | awk '/=/ {print $1}')
fi

# Clean install all dependencies (including dev for build)
echo "📦 Installing all dependencies..."
npm ci

# Build frontend and backend
echo "🏗️  Building React frontend and Express backend..."
npm run build

# Check if build was successful
if [ ! -d "dist/public" ]; then
    echo "❌ Frontend build failed - dist/public directory not found!"
    ls -la dist/ || echo "No dist directory found"
    exit 1
fi

if [ ! -f "dist/index.js" ]; then
    echo "❌ Backend build failed - dist/index.js not found!"
    ls -la dist/ || echo "No dist directory found"
    exit 1
fi

# Verify build contents
echo "📋 Build verification:"
echo "Frontend files:"
ls -la dist/public/ | head -10
echo "Backend file:"
ls -la dist/index.js

echo "✅ Build completed successfully"

# Create production directories
sudo mkdir -p /var/www/portfolio
sudo chown -R $USER:$USER /var/www/portfolio

# Copy built files and production dependencies
echo "📁 Copying application files..."
cp -r dist /var/www/portfolio/
cp package.json /var/www/portfolio/
cp package-lock.json /var/www/portfolio/
cp ecosystem.config.js /var/www/portfolio/
cp .env.production /var/www/portfolio/

# Change to production directory and install only production dependencies
cd /var/www/portfolio
echo "📦 Installing production dependencies..."
npm ci --omit=dev

# Create logs directory in production location
mkdir -p /var/www/portfolio/logs

# Stop existing application
echo "🛑 Stopping existing application..."
pm2 delete portfolio-api 2>/dev/null || true

# Start application with PM2
echo "🔧 Starting application with PM2..."
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 startup script
pm2 startup

echo "✅ Deployment completed successfully!"
echo "📊 Application status:"
pm2 status

echo ""
echo "🌐 Your application is now running!"
echo "API: http://localhost:5000"
echo "Frontend: Served via Nginx"
echo ""
echo "📝 Next steps:"
echo "1. Configure Nginx reverse proxy"
echo "2. Set up SSL with Let's Encrypt"  
echo "3. Configure your domain DNS"
