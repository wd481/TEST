
-- Database setup script for PostgreSQL
-- Run this with: psql -U postgres -f database-setup.sql

-- Create database
CREATE DATABASE portfolio_db;

-- Create user
CREATE USER portfolio_user WITH ENCRYPTED PASSWORD 'your_secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE portfolio_db TO portfolio_user;
ALTER DATABASE portfolio_db OWNER TO portfolio_user;

-- Connect to the database
\c portfolio_db;

-- Grant schema privileges
GRANT ALL ON SCHEMA public TO portfolio_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO portfolio_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO portfolio_user;

-- Create necessary extensions if needed
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

\q
