import { type User, type InsertUser, type BlogPost, type InsertBlogPost, type PortfolioContent, type InsertPortfolioContent } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Blog post methods
  getBlogPosts(): Promise<BlogPost[]>;
  getPublishedBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(id: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: string): Promise<boolean>;
  
  // Portfolio content methods
  getPortfolioContent(section: string): Promise<PortfolioContent[]>;
  getPortfolioContentByType(section: string, contentType: string): Promise<PortfolioContent | undefined>;
  updatePortfolioContent(content: InsertPortfolioContent): Promise<PortfolioContent>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private blogPosts: Map<string, BlogPost>;
  private portfolioContent: Map<string, PortfolioContent>;

  constructor() {
    this.users = new Map();
    this.blogPosts = new Map();
    this.portfolioContent = new Map();
    this.initializeDefaultContent();
  }

  private initializeDefaultContent() {
    // Initialize default portfolio content
    const defaultContent = [
      {
        id: randomUUID(),
        section: 'home',
        contentType: 'hero',
        data: {
          title: 'K Sai Kiran',
          subtitle: 'Cybersecurity Professional & Startup Founder',
          description: 'Securing digital frontiers while building innovative solutions through Hex Tech Solutions',
          stats: [
            { label: 'Years Experience', value: '8+' },
            { label: 'Security Audits', value: '150+' },
            { label: 'Clients Secured', value: '50+' },
            { label: 'Startup Founded', value: '1' }
          ]
        },
        updatedAt: new Date()
      },
      {
        id: randomUUID(),
        section: 'professional',
        contentType: 'experience',
        data: {
          experiences: [
            {
              title: 'Senior Cybersecurity Consultant',
              period: '2020 - Present',
              description: 'Leading cybersecurity initiatives for Fortune 500 companies, implementing comprehensive security frameworks and conducting advanced threat assessments.',
              skills: ['Penetration Testing', 'SIEM', 'Cloud Security']
            },
            {
              title: 'Security Operations Manager',
              period: '2018 - 2020',
              description: 'Managed 24/7 Security Operations Center, leading incident response teams and developing automated threat detection systems.',
              skills: ['SOC Management', 'Incident Response', 'Team Leadership']
            },
            {
              title: 'Cybersecurity Analyst',
              period: '2016 - 2018',
              description: 'Specialized in malware analysis, digital forensics, and vulnerability assessments for critical infrastructure protection.',
              skills: ['Malware Analysis', 'Digital Forensics', 'Vulnerability Assessment']
            }
          ]
        },
        updatedAt: new Date()
      },
      {
        id: randomUUID(),
        section: 'entrepreneurship',
        contentType: 'company',
        data: {
          name: 'Hex Tech Solutions',
          founded: '2021',
          description: 'Hex Tech Solutions was born from a vision to democratize advanced cybersecurity solutions for businesses of all sizes.',
          stats: [
            { label: 'Enterprise Clients', value: '25+' },
            { label: 'Revenue Protected', value: '$2M+' },
            { label: 'Team Members', value: '15' },
            { label: 'Uptime Record', value: '99.9%' }
          ],
          services: [
            {
              title: 'Threat Assessment',
              description: 'Comprehensive security audits and vulnerability assessments to identify and mitigate potential threats.',
              features: ['Penetration Testing', 'Vulnerability Scanning', 'Risk Analysis']
            },
            {
              title: 'Cloud Security',
              description: 'Secure cloud migration and management services for enterprise-grade protection.',
              features: ['AWS/Azure Security', 'Cloud Architecture', 'Compliance Management']
            },
            {
              title: 'Security Automation',
              description: 'Custom automation solutions for threat detection and incident response.',
              features: ['SOAR Implementation', 'Custom Dashboards', 'Alert Management']
            }
          ]
        },
        updatedAt: new Date()
      }
    ];

    defaultContent.forEach(content => {
      this.portfolioContent.set(content.id, content);
    });

    // Add sample blog posts
    const samplePosts = [
      {
        id: randomUUID(),
        title: 'The Future of Zero Trust Architecture in Enterprise Security',
        content: 'Exploring how Zero Trust principles are reshaping enterprise security strategies...',
        category: 'Cybersecurity',
        excerpt: 'Exploring how Zero Trust principles are reshaping enterprise security strategies and what organizations need to know for successful implementation.',
        published: true,
        createdAt: new Date('2023-12-15'),
        updatedAt: new Date('2023-12-15')
      },
      {
        id: randomUUID(),
        title: 'Building a Security-First Startup Culture',
        content: 'How we embedded security thinking into every aspect of our startup operations...',
        category: 'Entrepreneurship',
        excerpt: 'How we embedded security thinking into every aspect of our startup operations from day one.',
        published: true,
        createdAt: new Date('2023-12-10'),
        updatedAt: new Date('2023-12-10')
      },
      {
        id: randomUUID(),
        title: 'AI-Powered Threat Detection: Reality vs Hype',
        content: 'Separating genuine AI capabilities from marketing buzz in cybersecurity solutions...',
        category: 'Technology',
        excerpt: 'Separating genuine AI capabilities from marketing buzz in cybersecurity solutions.',
        published: true,
        createdAt: new Date('2023-12-05'),
        updatedAt: new Date('2023-12-05')
      }
    ];

    samplePosts.forEach(post => {
      this.blogPosts.set(post.id, post);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Blog post methods
  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getPublishedBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values())
      .filter(post => post.published)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getBlogPost(id: string): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const id = randomUUID();
    const now = new Date();
    const blogPost: BlogPost = {
      id,
      title: post.title,
      content: post.content,
      category: post.category,
      excerpt: post.excerpt || null,
      published: post.published || null,
      createdAt: now,
      updatedAt: now
    };
    this.blogPosts.set(id, blogPost);
    return blogPost;
  }

  async updateBlogPost(id: string, updates: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const existingPost = this.blogPosts.get(id);
    if (!existingPost) return undefined;

    const updatedPost: BlogPost = {
      ...existingPost,
      ...updates,
      updatedAt: new Date()
    };
    this.blogPosts.set(id, updatedPost);
    return updatedPost;
  }

  async deleteBlogPost(id: string): Promise<boolean> {
    return this.blogPosts.delete(id);
  }

  // Portfolio content methods
  async getPortfolioContent(section: string): Promise<PortfolioContent[]> {
    return Array.from(this.portfolioContent.values())
      .filter(content => content.section === section);
  }

  async getPortfolioContentByType(section: string, contentType: string): Promise<PortfolioContent | undefined> {
    return Array.from(this.portfolioContent.values())
      .find(content => content.section === section && content.contentType === contentType);
  }

  async updatePortfolioContent(content: InsertPortfolioContent): Promise<PortfolioContent> {
    const existing = Array.from(this.portfolioContent.values())
      .find(c => c.section === content.section && c.contentType === content.contentType);

    if (existing) {
      const updated: PortfolioContent = {
        ...existing,
        data: content.data,
        updatedAt: new Date()
      };
      this.portfolioContent.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const newContent: PortfolioContent = {
        id,
        ...content,
        updatedAt: new Date()
      };
      this.portfolioContent.set(id, newContent);
      return newContent;
    }
  }
}

export const storage = new MemStorage();
