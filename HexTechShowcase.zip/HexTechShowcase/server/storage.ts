
import { neon } from '@neondatabase/serverless';
import type { BlogPost, PortfolioContent } from '../shared/schema';

const sql = neon(process.env.DATABASE_URL || 'postgresql://localhost:5432/portfolio_db');

// Mock data for portfolio content
const mockPortfolioData: Record<string, PortfolioContent[]> = {
  home: [
    {
      id: 'hero-1',
      section: 'home',
      contentType: 'hero',
      title: 'K Sai Kiran',
      content: 'Full-Stack Developer & Cybersecurity Expert',
      metadata: {
        subtitle: 'Building secure, scalable solutions with cutting-edge technology',
        ctaText: 'View My Work',
        backgroundImage: '/hero-bg.jpg'
      },
      order: 1,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ],
  professional: [
    {
      id: 'skills-1',
      section: 'professional',
      contentType: 'skills',
      title: 'Technical Skills',
      content: 'Comprehensive technology stack expertise',
      metadata: {
        categories: [
          {
            name: 'Frontend',
            skills: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'Three.js']
          },
          {
            name: 'Backend',
            skills: ['Node.js', 'Express', 'PostgreSQL', 'MongoDB', 'Redis']
          },
          {
            name: 'Security',
            skills: ['Penetration Testing', 'Network Security', 'OWASP', 'Cryptography']
          },
          {
            name: 'DevOps',
            skills: ['AWS', 'Docker', 'CI/CD', 'Kubernetes', 'Terraform']
          }
        ]
      },
      order: 1,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ],
  entrepreneurship: [
    {
      id: 'timeline-1',
      section: 'entrepreneurship',
      contentType: 'timeline',
      title: 'HexTech Solutions Journey',
      content: 'Our evolution from startup to industry leader',
      metadata: {
        events: [
          {
            year: '2020',
            title: 'Foundation',
            description: 'Started with a vision to revolutionize cybersecurity',
            icon: 'rocket',
            achievements: ['Team Formation', 'Initial Funding', 'Core Product Development']
          },
          {
            year: '2021',
            title: 'First Product Launch',
            description: 'Launched our flagship security assessment platform',
            icon: 'product',
            achievements: ['100+ Clients', 'Security Certifications', 'Market Recognition']
          },
          {
            year: '2022',
            title: 'Expansion',
            description: 'Expanded services to include cloud security solutions',
            icon: 'growth',
            achievements: ['Cloud Security Suite', 'Enterprise Clients', 'Team Growth to 25+']
          },
          {
            year: '2023',
            title: 'Innovation',
            description: 'Introduced AI-powered threat detection capabilities',
            icon: 'ai',
            achievements: ['AI Integration', 'Patent Applications', 'Industry Awards']
          },
          {
            year: '2024',
            title: 'Global Reach',
            description: 'Expanding globally with AI-powered security solutions',
            icon: 'global',
            achievements: ['International Expansion', 'Advanced AI Models', 'Strategic Partnerships']
          }
        ]
      },
      order: 1,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ]
};

export const storage = {
  // Blog post methods
  async getBlogPosts(): Promise<BlogPost[]> {
    try {
      const result = await sql`
        SELECT * FROM blog_posts 
        ORDER BY created_at DESC
      `;
      return result as BlogPost[];
    } catch (error) {
      console.error('Database error, returning empty array:', error);
      return [];
    }
  },

  async getPublishedBlogPosts(): Promise<BlogPost[]> {
    try {
      const result = await sql`
        SELECT * FROM blog_posts 
        WHERE is_published = true 
        ORDER BY created_at DESC
      `;
      return result as BlogPost[];
    } catch (error) {
      console.error('Database error, returning empty array:', error);
      return [];
    }
  },

  async getBlogPost(id: string): Promise<BlogPost | null> {
    try {
      const result = await sql`
        SELECT * FROM blog_posts 
        WHERE id = ${id}
      `;
      return result[0] as BlogPost || null;
    } catch (error) {
      console.error('Database error:', error);
      return null;
    }
  },

  async createBlogPost(data: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>): Promise<BlogPost> {
    try {
      const result = await sql`
        INSERT INTO blog_posts (title, content, excerpt, is_published, tags, metadata)
        VALUES (${data.title}, ${data.content}, ${data.excerpt || ''}, ${data.isPublished || false}, ${JSON.stringify(data.tags || [])}, ${JSON.stringify(data.metadata || {})})
        RETURNING *
      `;
      return result[0] as BlogPost;
    } catch (error) {
      console.error('Database error:', error);
      throw new Error('Failed to create blog post');
    }
  },

  async updateBlogPost(id: string, data: Partial<BlogPost>): Promise<BlogPost | null> {
    try {
      const updates = [];
      const values = [];
      let paramIndex = 1;

      if (data.title !== undefined) {
        updates.push(`title = $${paramIndex}`);
        values.push(data.title);
        paramIndex++;
      }
      if (data.content !== undefined) {
        updates.push(`content = $${paramIndex}`);
        values.push(data.content);
        paramIndex++;
      }
      if (data.excerpt !== undefined) {
        updates.push(`excerpt = $${paramIndex}`);
        values.push(data.excerpt);
        paramIndex++;
      }
      if (data.isPublished !== undefined) {
        updates.push(`is_published = $${paramIndex}`);
        values.push(data.isPublished);
        paramIndex++;
      }
      if (data.tags !== undefined) {
        updates.push(`tags = $${paramIndex}`);
        values.push(JSON.stringify(data.tags));
        paramIndex++;
      }
      if (data.metadata !== undefined) {
        updates.push(`metadata = $${paramIndex}`);
        values.push(JSON.stringify(data.metadata));
        paramIndex++;
      }

      updates.push(`updated_at = NOW()`);
      values.push(id);

      const query = `
        UPDATE blog_posts 
        SET ${updates.join(', ')} 
        WHERE id = $${paramIndex}
        RETURNING *
      `;

      const result = await sql(query, values);
      return result[0] as BlogPost || null;
    } catch (error) {
      console.error('Database error:', error);
      return null;
    }
  },

  async deleteBlogPost(id: string): Promise<boolean> {
    try {
      const result = await sql`
        DELETE FROM blog_posts 
        WHERE id = ${id}
      `;
      return result.length > 0;
    } catch (error) {
      console.error('Database error:', error);
      return false;
    }
  },

  // Portfolio content methods
  async getPortfolioContent(section: string): Promise<PortfolioContent[]> {
    try {
      const result = await sql`
        SELECT * FROM portfolio_content 
        WHERE section = ${section} AND is_active = true
        ORDER BY "order" ASC
      `;
      
      if (result.length === 0) {
        // Return mock data if database is empty
        return mockPortfolioData[section] || [];
      }
      
      return result as PortfolioContent[];
    } catch (error) {
      console.error('Database error, returning mock data:', error);
      return mockPortfolioData[section] || [];
    }
  },

  async getPortfolioContentByType(section: string, contentType: string): Promise<PortfolioContent | null> {
    try {
      const result = await sql`
        SELECT * FROM portfolio_content 
        WHERE section = ${section} AND content_type = ${contentType} AND is_active = true
        ORDER BY "order" ASC
        LIMIT 1
      `;
      
      if (result.length === 0) {
        // Return mock data if database is empty
        const mockData = mockPortfolioData[section]?.find(item => item.contentType === contentType);
        return mockData || null;
      }
      
      return result[0] as PortfolioContent;
    } catch (error) {
      console.error('Database error, returning mock data:', error);
      const mockData = mockPortfolioData[section]?.find(item => item.contentType === contentType);
      return mockData || null;
    }
  },

  async updatePortfolioContent(data: Omit<PortfolioContent, 'createdAt' | 'updatedAt'>): Promise<PortfolioContent> {
    try {
      const result = await sql`
        INSERT INTO portfolio_content (id, section, content_type, title, content, metadata, "order", is_active)
        VALUES (${data.id}, ${data.section}, ${data.contentType}, ${data.title}, ${data.content}, ${JSON.stringify(data.metadata || {})}, ${data.order}, ${data.isActive})
        ON CONFLICT (id) DO UPDATE SET
          title = EXCLUDED.title,
          content = EXCLUDED.content,
          metadata = EXCLUDED.metadata,
          "order" = EXCLUDED."order",
          is_active = EXCLUDED.is_active,
          updated_at = NOW()
        RETURNING *
      `;
      return result[0] as PortfolioContent;
    } catch (error) {
      console.error('Database error:', error);
      throw new Error('Failed to update portfolio content');
    }
  }
};
