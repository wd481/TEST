
#!/bin/bash

# Installation script for AWS EC2 Ubuntu 22.04
echo "🔧 Installing system dependencies..."

# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20.x LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify Node.js and npm versions
echo "Node.js version: $(node --version)"
echo "npm version: $(npm --version)"

# Install additional tools
sudo apt install -y git nginx certbot python3-certbot-nginx unzip htop build-essential

# Install PM2 globally
sudo npm install -g pm2

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

echo "✅ System dependencies installed successfully!"
echo ""
echo "📝 Next steps:"
echo "1. Setup PostgreSQL database:"
echo "   sudo -u postgres psql -f database-setup.sql"
echo ""
echo "2. Configure environment variables in .env.production"
echo ""
echo "3. Run deployment script:"
echo "   chmod +x deploy.sh"
echo "   ./deploy.sh"
echo ""
echo "4. Configure Nginx:"
echo "   sudo cp nginx.conf /etc/nginx/sites-available/portfolio"
echo "   sudo ln -s /etc/nginx/sites-available/portfolio /etc/nginx/sites-enabled/"
echo "   sudo rm /etc/nginx/sites-enabled/default"
echo "   sudo nginx -t"
echo "   sudo systemctl restart nginx"
