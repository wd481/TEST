# Overview

A modern full-stack portfolio website built with React, TypeScript, and Express.js for K Sai Kiran, showcasing his expertise as a cybersecurity professional and startup founder. The application features a professional portfolio site with sections for home, professional experience, entrepreneurship, and blog posts. It includes an integrated content management system with an editor mode for live content editing.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for a type-safe, component-based UI
- **Vite** as the build tool and development server for fast hot module replacement
- **Wouter** for lightweight client-side routing instead of React Router
- **TailwindCSS** with shadcn/ui components for consistent, modern styling
- **Framer Motion** for smooth page transitions and animations
- **Three.js** for 3D floating particle effects in hero sections
- **TanStack Query** for efficient server state management and API caching

## Backend Architecture
- **Express.js** server with TypeScript for RESTful API endpoints
- **Modular route system** with separate storage abstraction layer
- **Memory-based storage** implementation with interface for future database migration
- **Middleware pipeline** for request logging, JSON parsing, and error handling
- **Development/production environment separation** with different static file serving strategies

## Data Storage Solutions
- **PostgreSQL** database configured with Drizzle ORM for type-safe database operations
- **Neon Database** as the serverless PostgreSQL provider
- **In-memory fallback storage** for development and testing
- **Drizzle migrations** system for database schema versioning

## Content Management System
- **Live editor mode** with toggleable UI for real-time content editing
- **Flexible JSON-based content structure** stored in portfolio_content table
- **Section-based content organization** (home, professional, entrepreneurship)
- **Blog post management** with draft/publish workflow
- **Form validation** using Zod schemas with React Hook Form

## Authentication and Authorization
- **Session-based authentication** prepared with connect-pg-simple for PostgreSQL session storage
- **User management schema** with username/password authentication ready for implementation
- **Editor mode access control** framework in place for content management permissions

# External Dependencies

## Database Services
- **Neon Database** - Serverless PostgreSQL hosting
- **Drizzle ORM** - Type-safe database toolkit and query builder
- **connect-pg-simple** - PostgreSQL session store for Express sessions

## UI and Styling
- **Radix UI** - Headless UI components for accessibility and consistency
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Pre-built component library built on Radix UI and Tailwind
- **Lucide React** - Icon library for consistent iconography
- **Framer Motion** - Animation library for page transitions

## Development and Build Tools
- **Vite** - Frontend build tool and development server
- **TypeScript** - Static type checking
- **ESBuild** - Fast JavaScript bundler for production builds
- **PostCSS** - CSS processing with Autoprefixer

## State Management and API
- **TanStack Query** - Server state management and caching
- **React Hook Form** - Form state management with validation
- **Zod** - Schema validation for type-safe data handling

## 3D Graphics and Animations
- **Three.js** - 3D graphics library for particle effects
- **CMDK** - Command palette component for enhanced UX

## Replit Integration
- **@replit/vite-plugin-runtime-error-modal** - Development error handling
- **@replit/vite-plugin-cartographer** - Development tools integration