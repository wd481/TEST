import * as THREE from 'three';

export function createFloatingParticles(scene: THREE.Scene) {
  const particlesGeometry = new THREE.BufferGeometry();
  const particleCount = 100;
  const positions = new Float32Array(particleCount * 3);

  for (let i = 0; i < particleCount * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 20;
  }

  particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

  const particlesMaterial = new THREE.PointsMaterial({
    color: 0x06b6d4,
    size: 0.02,
    transparent: true,
    opacity: 0.6
  });

  const particles = new THREE.Points(particlesGeometry, particlesMaterial);
  scene.add(particles);

  return particles;
}

export function animateParticles(particles: THREE.Points) {
  particles.rotation.x += 0.001;
  particles.rotation.y += 0.002;
}

export function createGradientMaterial() {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const context = canvas.getContext('2d')!;
  
  const gradient = context.createLinearGradient(0, 0, 256, 256);
  gradient.addColorStop(0, '#1e3a8a');
  gradient.addColorStop(1, '#3b82f6');
  
  context.fillStyle = gradient;
  context.fillRect(0, 0, 256, 256);
  
  const texture = new THREE.CanvasTexture(canvas);
  return new THREE.MeshBasicMaterial({ map: texture, transparent: true, opacity: 0.1 });
}
