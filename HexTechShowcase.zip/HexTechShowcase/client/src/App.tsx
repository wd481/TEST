import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/layout/navigation";
import { Footer } from "@/components/layout/footer";
import Home from "@/pages/home";
import Professional from "@/pages/professional";
import Entrepreneurship from "@/pages/entrepreneurship";
import WriteUp from "@/pages/writeup";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen">
      <Navigation />

      <Switch>
        <Route path="/" component={() => <Home isActive={true} />} />
        <Route path="/professional" component={() => <Professional isActive={true} />} />
        <Route path="/entrepreneurship" component={() => <Entrepreneurship isActive={true} />} />
        <Route path="/writeup" component={() => <WriteUp isActive={true} />} />
        <Route component={NotFound} />
      </Switch>

      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
