import { Link } from 'wouter';
import { Linkedin, Twitter, Github, Globe, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy text-white py-12" data-testid="footer">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div data-testid="footer-brand">
            <h3 className="text-2xl font-poppins font-bold mb-4">K Sai Kiran</h3>
            <p className="text-blue-200 mb-4">Cybersecurity Professional & Startup Founder</p>
            <div className="flex space-x-4">
              <a
                href="https://linkedin.com"
                className="hover:text-teal transition-colors"
                aria-label="LinkedIn"
                data-testid="social-linkedin"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://twitter.com"
                className="hover:text-teal transition-colors"
                aria-label="Twitter"
                data-testid="social-twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="https://github.com"
                className="hover:text-teal transition-colors"
                aria-label="GitHub"
                data-testid="social-github"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://hextech.solutions"
                className="hover:text-teal transition-colors"
                aria-label="Website"
                data-testid="social-website"
              >
                <Globe className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div data-testid="footer-links">
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-blue-200">
              <li>
                <Link href="/" className="hover:text-white transition-colors" data-testid="footer-link-home">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/professional" className="hover:text-white transition-colors" data-testid="footer-link-professional">
                  Professional Experience
                </Link>
              </li>
              <li>
                <Link href="/entrepreneurship" className="hover:text-white transition-colors" data-testid="footer-link-entrepreneurship">
                  Entrepreneurship
                </Link>
              </li>
              <li>
                <Link href="/writeup" className="hover:text-white transition-colors" data-testid="footer-link-blog">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          
          <div data-testid="footer-services">
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-blue-200">
              <li>
                <a href="#" className="hover:text-white transition-colors" data-testid="service-consulting">
                  Security Consulting
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors" data-testid="service-assessment">
                  Threat Assessment
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors" data-testid="service-cloud">
                  Cloud Security
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors" data-testid="service-training">
                  Training & Workshops
                </a>
              </li>
            </ul>
          </div>
          
          <div data-testid="footer-contact">
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-blue-200">
              <li className="flex items-center" data-testid="contact-email">
                <Mail className="w-4 h-4 mr-2" />
                hello@hextech.solutions
              </li>
              <li className="flex items-center" data-testid="contact-phone">
                <Phone className="w-4 h-4 mr-2" />
                +1 (555) 123-4567
              </li>
              <li className="flex items-center" data-testid="contact-location">
                <MapPin className="w-4 h-4 mr-2" />
                San Francisco, CA
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-blue-800 mt-8 pt-8 text-center text-blue-200" data-testid="footer-copyright">
          <p>&copy; {currentYear} K Sai Kiran. All rights reserved. Built with security in mind.</p>
        </div>
      </div>
    </footer>
  );
}
