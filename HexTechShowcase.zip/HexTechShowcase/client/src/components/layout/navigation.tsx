import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Home', testId: 'nav-home' },
    { path: '/professional', label: 'Professional', testId: 'nav-professional' },
    { path: '/entrepreneurship', label: 'Entrepreneurship', testId: 'nav-entrepreneurship' },
    { path: '/writeup', label: 'Write-Up', testId: 'nav-writeup' },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>

      {/* Main Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-30 glass-effect border-b border-white/20" data-testid="main-navigation">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="text-2xl font-poppins font-bold text-navy" data-testid="logo-link">
              K Sai Kiran
            </Link>
            
            <div className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`nav-item text-navy hover:text-light-blue font-medium transition-colors ${
                    location === item.path ? 'text-light-blue' : ''
                  }`}
                  data-testid={item.testId}
                >
                  {item.label}
                </Link>
              ))}
            </div>
            
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMobileMenu}
                className="text-navy"
                data-testid="mobile-menu-toggle"
              >
                {isMobileMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-20 bg-navy/95 md:hidden" data-testid="mobile-menu">
          <div className="flex flex-col items-center justify-center h-full space-y-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className="text-white text-2xl font-poppins hover:text-teal transition-colors"
                onClick={toggleMobileMenu}
                data-testid={`mobile-${item.testId}`}
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
