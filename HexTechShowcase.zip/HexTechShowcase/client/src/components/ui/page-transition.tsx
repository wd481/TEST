import { ReactNode, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PageTransitionProps {
  children: ReactNode;
  isActive: boolean;
  className?: string;
}

export function PageTransition({ children, isActive, className = '' }: PageTransitionProps) {
  const [shouldRender, setShouldRender] = useState(isActive);

  useEffect(() => {
    if (isActive) {
      setShouldRender(true);
    }
  }, [isActive]);

  const handleExitComplete = () => {
    if (!isActive) {
      setShouldRender(false);
    }
  };

  return (
    <AnimatePresence mode="wait" onExitComplete={handleExitComplete}>
      {shouldRender && (
        <motion.div
          key="page-content"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className={`page-transition ${isActive ? 'active' : ''} ${className}`}
          data-testid="page-transition"
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
