
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { PageTransition } from '@/components/ui/page-transition';
import { Shield, Cloud, ServerCog, Users, TrendingUp, Award, Rocket } from 'lucide-react';
import type { PortfolioContent } from '@shared/schema';

export default function Entrepreneurship() {
  const [isActive, setIsActive] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsActive(true);
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const { data: content } = useQuery<PortfolioContent>({
    queryKey: ['portfolio', 'entrepreneurship', 'company'],
    queryFn: async () => {
      const response = await fetch('/api/portfolio/entrepreneurship/company');
      if (!response.ok) throw new Error('Failed to fetch content');
      return response.json();
    }
  });

  const companyData = content?.content?.company || {
    name: "Hex Tech Solutions",
    description: "Innovative cybersecurity solutions for modern enterprises",
    mission: "To provide cutting-edge security technologies that protect businesses from evolving cyber threats",
    vision: "To be the leading provider of AI-powered cybersecurity solutions globally",
    services: [
      {
        title: "Cloud Security",
        description: "Comprehensive cloud infrastructure protection",
        icon: "Cloud"
      },
      {
        title: "Network Security",
        description: "Advanced network monitoring and threat detection",
        icon: "Shield"
      },
      {
        title: "Security Consulting",
        description: "Expert guidance on cybersecurity strategy",
        icon: "Users"
      },
      {
        title: "Managed Services",
        description: "24/7 security operations center services",
        icon: "ServerCog"
      }
    ],
    achievements: [
      {
        title: "50+ Clients Secured",
        description: "Successfully protected over 50 enterprise clients",
        icon: "Award"
      },
      {
        title: "99.9% Uptime",
        description: "Maintained exceptional service reliability",
        icon: "TrendingUp"
      },
      {
        title: "Industry Recognition",
        description: "Featured in top cybersecurity publications",
        icon: "Award"
      }
    ]
  };

  const milestones = [
    {
      year: '2018',
      title: 'Company Founded',
      description: 'Started Hex Tech Solutions with a vision to revolutionize cybersecurity',
      color: 'navy'
    },
    {
      year: '2019',
      title: 'First Major Client',
      description: 'Secured our first enterprise client and established our reputation',
      color: 'light-blue'
    },
    {
      year: '2020',
      title: 'Team Expansion',
      description: 'Grew the team to 10+ cybersecurity experts and developers',
      color: 'teal'
    },
    {
      year: '2021',
      title: 'AI Integration',
      description: 'Launched AI-powered threat detection capabilities',
      color: 'navy'
    },
    {
      year: '2022',
      title: 'Market Leadership',
      description: 'Became a recognized leader in cloud security solutions',
      color: 'light-blue'
    },
    {
      year: '2023',
      title: 'Global Reach',
      description: 'Expanded operations to serve clients across multiple continents',
      color: 'teal'
    }
  ];

  const getIcon = (iconName: string) => {
    const icons = {
      Cloud,
      Shield,
      Users,
      ServerCog,
      Award,
      TrendingUp
    };
    return icons[iconName as keyof typeof icons] || Shield;
  };

  return (
    <PageTransition isActive={isActive}>
      <div className="min-h-screen py-12 md:py-20 bg-white" data-testid="entrepreneurship-page">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          {/* Header Section */}
          <div className={`text-center mb-12 md:mb-16 transition-all duration-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-poppins font-bold text-navy mb-4 md:mb-6" data-testid="entrepreneurship-title">
              Entrepreneurship Journey
            </h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto" data-testid="entrepreneurship-description">
              Building innovative cybersecurity solutions and leading digital transformation in the security industry.
            </p>
          </div>

          {/* Company Overview */}
          <div className={`mb-16 md:mb-20 transition-all duration-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} 
               style={{ transitionDelay: '200ms' }}>
            <Card className="overflow-hidden shadow-xl border-0">
              <div className="hero-gradient p-8 md:p-12 text-white">
                <div className="max-w-4xl mx-auto text-center">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4 md:mb-6">{companyData.name}</h2>
                  <p className="text-lg md:text-xl mb-6 md:mb-8 text-white/90">{companyData.description}</p>
                  <div className="grid md:grid-cols-2 gap-6 md:gap-8 text-left">
                    <div>
                      <h3 className="text-xl font-semibold mb-3">Our Mission</h3>
                      <p className="text-white/90">{companyData.mission}</p>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-3">Our Vision</h3>
                      <p className="text-white/90">{companyData.vision}</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Services Grid */}
          <div className={`mb-16 md:mb-20 transition-all duration-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} 
               style={{ transitionDelay: '400ms' }}>
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-navy">Our Services</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {companyData.services.map((service, index) => {
                const Icon = getIcon(service.icon);
                return (
                  <Card key={index} className="card-hover text-center p-4 md:p-6 border-0 shadow-lg">
                    <CardContent className="p-0">
                      <div className="w-12 h-12 md:w-16 md:h-16 bg-navy rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                        <Icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                      </div>
                      <h3 className="text-lg md:text-xl font-bold text-navy mb-2">{service.title}</h3>
                      <p className="text-sm md:text-base text-gray-600">{service.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Timeline Section */}
          <div className={`mb-16 md:mb-20 transition-all duration-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} 
               style={{ transitionDelay: '600ms' }}>
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-navy">Company Timeline</h2>
            
            {/* Desktop Timeline */}
            <div className="hidden md:block relative">
              {/* Center Line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-navy via-light-blue to-teal"></div>
              
              <div className="space-y-8 md:space-y-12">
                {milestones.map((milestone, index) => (
                  <div key={index} className={`relative transition-all duration-400 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
                       style={{ transitionDelay: `${800 + index * 150}ms` }}>
                    {/* Timeline Node */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-white border-4 shadow-lg z-10"
                         style={{ borderColor: milestone.color === 'navy' ? 'var(--navy)' : 
                                              milestone.color === 'light-blue' ? 'var(--light-blue)' : 'var(--teal)' }}></div>
                    
                    {/* Content Card */}
                    <div className={`w-full flex ${index % 2 === 0 ? 'justify-start pr-8' : 'justify-end pl-8'}`}>
                      <div className={`relative bg-white rounded-2xl shadow-xl p-6 max-w-md border-l-4 transition-all duration-400 hover:shadow-2xl hover:-translate-y-2 ${
                        milestone.color === 'navy' ? 'border-navy' : 
                        milestone.color === 'light-blue' ? 'border-light-blue' : 'border-teal'
                      }`}>
                        {/* Connection Line to Center */}
                        <div className={`absolute top-1/2 w-8 h-0.5 ${
                          milestone.color === 'navy' ? 'bg-navy' : 
                          milestone.color === 'light-blue' ? 'bg-light-blue' : 'bg-teal'
                        } ${index % 2 === 0 ? 'right-0 translate-x-full' : 'left-0 -translate-x-full'}`}></div>
                        
                        <div className="flex items-center mb-4">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold mr-4 ${
                            milestone.color === 'navy' ? 'bg-navy' : 
                            milestone.color === 'light-blue' ? 'bg-light-blue' : 'bg-teal'
                          }`}>
                            {milestone.year}
                          </div>
                          <h3 className="text-xl font-bold text-navy">{milestone.title}</h3>
                        </div>
                        <p className="text-gray-600">{milestone.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Future Milestone */}
                <div className={`relative transition-all duration-400 ${isVisible ? 'opacity-100' : 'opacity-0'}`} 
                     style={{ transitionDelay: '1400ms' }}>
                  <div className="w-full flex justify-center">
                    <div className="relative bg-gradient-to-br from-navy to-teal rounded-2xl shadow-xl p-8 max-w-md text-white text-center transform hover:scale-105 transition-all duration-400">
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Rocket className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">2024 & Beyond</h3>
                      <p className="text-white/90">Expanding globally with AI-powered security solutions</p>
                    </div>
                  </div>
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-br from-navy to-teal border-4 border-white shadow-lg z-10"></div>
                </div>
              </div>
            </div>

            {/* Mobile Timeline */}
            <div className="md:hidden space-y-6">
              {milestones.map((milestone, index) => (
                <div key={index} className={`relative transition-all duration-400 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'}`}
                     style={{ transitionDelay: `${800 + index * 100}ms` }}>
                  <div className={`bg-white rounded-xl shadow-lg p-4 border-l-4 ${
                    milestone.color === 'navy' ? 'border-navy' : 
                    milestone.color === 'light-blue' ? 'border-light-blue' : 'border-teal'
                  }`}>
                    <div className="flex items-center mb-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold mr-3 ${
                        milestone.color === 'navy' ? 'bg-navy' : 
                        milestone.color === 'light-blue' ? 'bg-light-blue' : 'bg-teal'
                      }`}>
                        {milestone.year}
                      </div>
                      <h3 className="text-lg font-bold text-navy">{milestone.title}</h3>
                    </div>
                    <p className="text-gray-600 text-sm">{milestone.description}</p>
                  </div>
                </div>
              ))}
              
              {/* Future Milestone Mobile */}
              <div className={`transition-all duration-400 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'}`} 
                   style={{ transitionDelay: '1200ms' }}>
                <div className="bg-gradient-to-br from-navy to-teal rounded-xl shadow-lg p-6 text-white text-center">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Rocket className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">2024 & Beyond</h3>
                  <p className="text-white/90 text-sm">Expanding globally with AI-powered security solutions</p>
                </div>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className={`transition-all duration-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} 
               style={{ transitionDelay: '1000ms' }}>
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-navy">Key Achievements</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {companyData.achievements.map((achievement, index) => {
                const Icon = getIcon(achievement.icon);
                return (
                  <Card key={index} className="card-hover text-center p-4 md:p-6 border-0 shadow-lg">
                    <CardContent className="p-0">
                      <div className="w-12 h-12 md:w-16 md:h-16 bg-teal rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                        <Icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                      </div>
                      <h3 className="text-lg md:text-xl font-bold text-navy mb-2">{achievement.title}</h3>
                      <p className="text-sm md:text-base text-gray-600">{achievement.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
