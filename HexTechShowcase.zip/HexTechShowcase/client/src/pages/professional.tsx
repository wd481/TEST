import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PageTransition } from '@/components/ui/page-transition';
import { Shield, Users, Award, Cloud } from 'lucide-react';
import type { PortfolioContent } from '@shared/schema';

interface ProfessionalProps {
  isActive: boolean;
}

export default function Professional({ isActive }: ProfessionalProps) {
  const [isVisible, setIsVisible] = useState(false);

  const { data: experienceContent } = useQuery<PortfolioContent>({
    queryKey: ['/api/portfolio/professional/experience'],
    enabled: isActive,
  });

  useEffect(() => {
    if (isActive) {
      const timer = setTimeout(() => setIsVisible(true), 100);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
    }
  }, [isActive]);

  const experienceData = experienceContent?.data as any;
  const experiences = experienceData?.experiences || [
    {
      title: 'Senior Cybersecurity Consultant',
      period: '2020 - Present',
      description: 'Leading cybersecurity initiatives for Fortune 500 companies, implementing comprehensive security frameworks and conducting advanced threat assessments.',
      skills: ['Penetration Testing', 'SIEM', 'Cloud Security']
    },
    {
      title: 'Security Operations Manager',
      period: '2018 - 2020',
      description: 'Managed 24/7 Security Operations Center, leading incident response teams and developing automated threat detection systems.',
      skills: ['SOC Management', 'Incident Response', 'Team Leadership']
    },
    {
      title: 'Cybersecurity Analyst',
      period: '2016 - 2018',
      description: 'Specialized in malware analysis, digital forensics, and vulnerability assessments for critical infrastructure protection.',
      skills: ['Malware Analysis', 'Digital Forensics', 'Vulnerability Assessment']
    }
  ];

  const techSkills = [
    { name: 'Penetration Testing', level: 95, color: 'navy' },
    { name: 'Cloud Security', level: 85, color: 'light-blue' },
    { name: 'Incident Response', level: 92, color: 'teal' },
    { name: 'Risk Assessment', level: 88, color: 'navy' }
  ];

  const certifications = [
    { name: 'CISSP', description: 'Certified Information Systems Security Professional', icon: Shield },
    { name: 'CEH', description: 'Certified Ethical Hacker', icon: Users },
    { name: 'AWS Security', description: 'AWS Certified Security - Specialty', icon: Cloud },
    { name: 'CISM', description: 'Certified Information Security Manager', icon: Award }
  ];

  return (
    <PageTransition isActive={isActive}>
      <div className="min-h-screen py-20 bg-white" data-testid="professional-page">
        <div className="max-w-7xl mx-auto px-6">
          <div className={`text-center mb-16 transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h1 className="text-5xl lg:text-6xl font-poppins font-bold text-navy mb-6" data-testid="professional-title">
              Professional Experience
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="professional-description">
              A comprehensive journey through cybersecurity leadership, technical expertise, and industry recognition.
            </p>
          </div>

          {/* Experience Timeline */}
          <div className="relative mb-20">
            <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gradient-to-b from-navy to-teal"></div>
            
            {experiences.map((experience: any, index: number) => (
              <div 
                key={experience.title}
                className={`relative mb-16 transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}
                style={{ transitionDelay: `${400 + index * 300}ms` }}
                data-testid={`experience-${index}`}
              >
                <div className={`lg:grid lg:grid-cols-2 lg:gap-12 items-center ${index % 2 === 0 ? '' : 'lg:flex-row-reverse'}`}>
                  <div className={index % 2 === 0 ? 'lg:text-right' : ''}>
                    <div className="inline-block bg-navy text-white px-4 py-2 rounded-full text-sm font-mono mb-4">
                      {experience.period}
                    </div>
                    <h3 className="text-2xl font-poppins font-bold text-navy mb-4">{experience.title}</h3>
                    <p className="text-gray-600 mb-6">{experience.description}</p>
                    <div className={`flex flex-wrap gap-2 ${index % 2 === 0 ? 'lg:justify-end' : ''}`}>
                      {experience.skills.map((skill: string) => (
                        <Badge key={skill} variant="secondary" className="bg-blue-100 text-navy">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className={`mt-8 lg:mt-0 ${index % 2 === 0 ? 'lg:order-2' : 'lg:order-1'}`}>
                    <img 
                      src={`https://images.unsplash.com/photo-${index === 0 ? '1550751827-4bd374c3f58b' : index === 1 ? '1560472354-b33ff0c44a43' : '1551287373-dee9de6f5a8f'}?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400`}
                      alt={`${experience.title} workspace`}
                      className="rounded-2xl shadow-xl w-full h-64 object-cover"
                    />
                  </div>
                </div>
                <div className="absolute left-1/2 top-8 transform -translate-x-1/2 w-4 h-4 bg-navy rounded-full border-4 border-white shadow-lg"></div>
              </div>
            ))}
          </div>

          {/* Skills & Certifications */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Technical Skills */}
            <Card className={`transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`} style={{ transitionDelay: '1200ms' }}>
              <CardContent className="p-8">
                <h3 className="text-2xl font-poppins font-bold text-navy mb-6" data-testid="skills-title">
                  Technical Expertise
                </h3>
                <div className="space-y-6">
                  {techSkills.map((skill, index) => (
                    <div key={skill.name} data-testid={`skill-${index}`}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">{skill.name}</span>
                        <span className="text-sm text-gray-600">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className={`bg-${skill.color} h-3 rounded-full transition-all duration-1000`}
                          style={{ 
                            width: isVisible ? `${skill.level}%` : '0%',
                            transitionDelay: `${1400 + index * 200}ms`
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Certifications */}
            <Card className={`transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`} style={{ transitionDelay: '1400ms' }}>
              <CardContent className="p-8">
                <h3 className="text-2xl font-poppins font-bold text-navy mb-6" data-testid="certifications-title">
                  Certifications
                </h3>
                <div className="space-y-4">
                  {certifications.map((cert, index) => (
                    <div 
                      key={cert.name}
                      className={`flex items-center p-4 bg-white rounded-lg shadow border transition-all duration-600 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                      style={{ transitionDelay: `${1600 + index * 150}ms` }}
                      data-testid={`certification-${index}`}
                    >
                      <div className="w-12 h-12 bg-navy/10 rounded-lg flex items-center justify-center mr-4">
                        <cert.icon className="w-6 h-6 text-navy" />
                      </div>
                      <div>
                        <div className="font-semibold text-navy">{cert.name}</div>
                        <div className="text-sm text-gray-600">{cert.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
