import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { PageTransition } from '@/components/ui/page-transition';

import { User, Calendar, ArrowRight } from 'lucide-react';
import type { BlogPost } from '@shared/schema';

interface WriteUpProps {
  isActive: boolean;
}

export default function WriteUp({ isActive }: WriteUpProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');

  const { data: blogPosts = [], isLoading } = useQuery<BlogPost[]>({
    queryKey: ['/api/blog/posts'],
    enabled: isActive,
  });

  useEffect(() => {
    if (isActive) {
      const timer = setTimeout(() => setIsVisible(true), 100);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
    }
  }, [isActive]);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement newsletter subscription
    console.log('Newsletter subscription:', email);
    setEmail('');
  };

  const featuredPost = blogPosts.find(post => post.title.toLowerCase().includes('zero trust')) || blogPosts[0];
  const recentPosts = blogPosts.slice(0, 6);

  const categoryColors: Record<string, string> = {
    'Cybersecurity': 'navy',
    'Entrepreneurship': 'teal',
    'Technology': 'light-blue',
    'Industry Updates': 'navy',
    'Career': 'teal',
    'Future Trends': 'light-blue'
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <PageTransition isActive={isActive}>
      <div className="min-h-screen py-20 bg-white" data-testid="writeup-page">
        <div className="max-w-7xl mx-auto px-6">
          <div className={`text-center mb-16 transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h1 className="text-5xl lg:text-6xl font-poppins font-bold text-navy mb-6" data-testid="writeup-title">
              Write-Up & Blog
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="writeup-description">
              Insights, thoughts, and updates on cybersecurity trends, entrepreneurship, and technology innovation.
            </p>
          </div>

          

          {/* Featured Post and Recent Posts */}
          {!isLoading && blogPosts.length > 0 && (
            <div className="grid lg:grid-cols-3 gap-8 mb-16">
              {/* Featured Post */}
              <div className="lg:col-span-2">
                {featuredPost && (
                  <Card 
                    className={`hero-gradient text-white card-hover transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}
                    style={{ transitionDelay: '400ms' }}
                    data-testid="featured-post"
                  >
                    <CardContent className="p-8">
                      <div className="text-sm font-mono mb-4 text-blue-200">
                        FEATURED POST • {featuredPost.category.toUpperCase()}
                      </div>
                      <h2 className="text-3xl font-poppins font-bold mb-4">{featuredPost.title}</h2>
                      <p className="text-blue-100 mb-6 leading-relaxed">
                        {featuredPost.excerpt}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mr-3">
                            <User className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="font-semibold">K Sai Kiran</div>
                            <div className="text-sm text-blue-200">
                              {formatDate(featuredPost.createdAt || new Date())}
                            </div>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          className="bg-white/20 hover:bg-white/30 text-white"
                          data-testid="featured-post-read-more"
                        >
                          Read More <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
              
              {/* Recent Posts Sidebar */}
              <div className="space-y-6">
                {blogPosts.slice(1, 3).map((post, index) => (
                  <Card 
                    key={post.id}
                    className={`card-hover transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}
                    style={{ transitionDelay: `${600 + index * 200}ms` }}
                    data-testid={`sidebar-post-${index}`}
                  >
                    <CardContent className="p-6">
                      <Badge 
                        variant="secondary" 
                        className={`text-${categoryColors[post.category] || 'navy'} mb-2`}
                      >
                        {post.category}
                      </Badge>
                      <h3 className="text-xl font-bold text-navy mb-3">{post.title}</h3>
                      <p className="text-gray-600 text-sm mb-4">{post.excerpt}</p>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {formatDate(post.createdAt || new Date())}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Recent Posts Grid */}
          <div>
            <h2 className={`text-3xl font-poppins font-bold text-navy mb-8 transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} style={{ transitionDelay: '1000ms' }} data-testid="recent-posts-title">
              Recent Posts
            </h2>
            
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index} className="animate-pulse" data-testid={`loading-card-${index}`}>
                    <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-6 bg-gray-200 rounded mb-3"></div>
                      <div className="h-16 bg-gray-200 rounded mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : recentPosts.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {recentPosts.map((post, index) => (
                  <Card 
                    key={post.id}
                    className={`overflow-hidden card-hover transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                    style={{ transitionDelay: `${1200 + index * 150}ms` }}
                    data-testid={`blog-post-${index}`}
                  >
                    <img 
                      src={`https://images.unsplash.com/photo-${index % 2 === 0 ? '1563013544-824ae1b704d3' : '1552664730-d307ca884978'}?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250`}
                      alt={`${post.category} illustration`}
                      className="w-full h-48 object-cover"
                    />
                    <CardContent className="p-6">
                      <Badge 
                        variant="secondary" 
                        className={`text-${categoryColors[post.category] || 'navy'} mb-2`}
                      >
                        {post.category}
                      </Badge>
                      <h3 className="text-xl font-bold text-navy mb-3">{post.title}</h3>
                      <p className="text-gray-600 text-sm mb-4">{post.excerpt}</p>
                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-500 flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {formatDate(post.createdAt || new Date())}
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="text-light-blue hover:text-navy p-0"
                          data-testid={`read-more-${index}`}
                        >
                          Read More →
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12" data-testid="no-posts">
                <p className="text-gray-600 text-lg">No blog posts available yet.</p>
              </div>
            )}
          </div>

          {/* Newsletter Signup */}
          <div className={`mt-16 hero-gradient rounded-2xl p-8 text-center text-white transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} style={{ transitionDelay: '2000ms' }} data-testid="newsletter-section">
            <h2 className="text-3xl font-poppins font-bold mb-4">Stay Updated</h2>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Subscribe to receive the latest insights on cybersecurity, entrepreneurship, and technology trends directly in your inbox.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex max-w-md mx-auto">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex-1 rounded-r-none text-gray-800 border-0"
                required
                data-testid="newsletter-email-input"
              />
              <Button 
                type="submit"
                className="bg-teal hover:bg-teal/90 rounded-l-none"
                data-testid="newsletter-subscribe-button"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
