import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FloatingParticles } from '@/components/three/floating-particles';
import { PageTransition } from '@/components/ui/page-transition';
import { Download, Mail, Shield, Rocket, Code } from 'lucide-react';
import type { PortfolioContent } from '@shared/schema';

interface HomeProps {
  isActive: boolean;
}

export default function Home({ isActive }: HomeProps) {
  const [isVisible, setIsVisible] = useState(false);

  const { data: heroContent } = useQuery<PortfolioContent>({
    queryKey: ['/api/portfolio/home/hero'],
    enabled: isActive,
  });

  useEffect(() => {
    if (isActive) {
      const timer = setTimeout(() => setIsVisible(true), 100);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
    }
  }, [isActive]);

  const heroData = heroContent?.data as any;
  const stats = heroData?.stats || [
    { label: 'Years Experience', value: '8+' },
    { label: 'Security Audits', value: '150+' },
    { label: 'Clients Secured', value: '50+' },
    { label: 'Startup Founded', value: '1' }
  ];

  return (
    <PageTransition isActive={isActive}>
      <div className="min-h-screen" data-testid="home-page">
        {/* Hero Section */}
        <div className="hero-gradient min-h-screen flex items-center relative overflow-hidden">
          <FloatingParticles className="absolute inset-0" />
          
          <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className={`text-white transition-all duration-800 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
                <div className="text-sm font-mono mb-4 text-blue-200" data-testid="hero-subtitle">
                  CYBERSECURITY EXPERT • STARTUP FOUNDER
                </div>
                <h1 className="text-5xl lg:text-7xl font-poppins font-bold mb-6 leading-tight" data-testid="hero-title">
                  {heroData?.title || 'K Sai Kiran'}
                </h1>
                <p className="text-xl lg:text-2xl mb-8 text-blue-100 leading-relaxed" data-testid="hero-description">
                  {heroData?.description || (
                    <>
                      Securing digital frontiers while building innovative solutions through{' '}
                      <span className="text-teal font-semibold">Hex Tech Solutions</span>
                    </>
                  )}
                </p>
                
                <div className="flex flex-wrap gap-4 mb-8">
                  <Button 
                    className="bg-white text-navy hover:bg-blue-50 card-hover px-8 py-4 text-lg"
                    data-testid="download-cv-button"
                  >
                    <Download className="mr-2 w-5 h-5" />
                    Download CV
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-2 border-white text-white hover:bg-white hover:text-navy px-8 py-4 text-lg"
                    data-testid="contact-button"
                  >
                    <Mail className="mr-2 w-5 h-5" />
                    Get in Touch
                  </Button>
                </div>
                
                <div className="flex space-x-6" data-testid="social-links">
                  <a href="https://linkedin.com" className="text-white hover:text-teal transition-colors text-2xl" data-testid="social-linkedin">
                    <span className="sr-only">LinkedIn</span>
                    💼
                  </a>
                  <a href="https://twitter.com" className="text-white hover:text-teal transition-colors text-2xl" data-testid="social-twitter">
                    <span className="sr-only">Twitter</span>
                    🐦
                  </a>
                  <a href="https://github.com" className="text-white hover:text-teal transition-colors text-2xl" data-testid="social-github">
                    <span className="sr-only">GitHub</span>
                    💻
                  </a>
                  <a href="https://hextech.solutions" className="text-white hover:text-teal transition-colors text-2xl" data-testid="social-website">
                    <span className="sr-only">Website</span>
                    🌐
                  </a>
                </div>
              </div>
              
              <div className={`flex justify-center transition-all duration-800 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=600" 
                    alt="K Sai Kiran - Cybersecurity Professional" 
                    className="rounded-2xl shadow-2xl w-80 h-96 object-cover animate-float"
                    data-testid="hero-image"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-teal text-white p-4 rounded-xl shadow-lg animate-glow">
                    <Shield className="w-8 h-8" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-4 gap-8" data-testid="stats-section">
              {stats.map((stat: any, index: number) => (
                <div 
                  key={stat.label}
                  className={`text-center transition-all duration-600 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                  style={{ transitionDelay: `${800 + index * 100}ms` }}
                  data-testid={`stat-${index}`}
                >
                  <div className="text-4xl font-bold text-navy mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* About Preview */}
        <div className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6">
            <div className={`text-center mb-16 transition-all duration-800 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} style={{ transitionDelay: '1200ms' }}>
              <h2 className="text-4xl lg:text-5xl font-poppins font-bold text-navy mb-6" data-testid="about-title">
                About Me
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="about-description">
                A passionate cybersecurity professional dedicated to protecting digital assets while driving innovation through technology entrepreneurship.
              </p>
            </div>
            
            <div className="grid lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Shield,
                  title: 'Cybersecurity Expert',
                  description: 'Specialized in threat detection, vulnerability assessment, and security architecture design for enterprise environments.',
                  color: 'navy'
                },
                {
                  icon: Rocket,
                  title: 'Startup Founder',
                  description: 'Founded Hex Tech Solutions to bridge the gap between cutting-edge security technology and business needs.',
                  color: 'light-blue'
                },
                {
                  icon: Code,
                  title: 'Tech Innovator',
                  description: 'Constantly exploring emerging technologies to create robust, scalable security solutions for modern challenges.',
                  color: 'teal'
                }
              ].map((item, index) => (
                <Card 
                  key={item.title}
                  className={`card-hover transition-all duration-600 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                  style={{ transitionDelay: `${1400 + index * 200}ms` }}
                  data-testid={`about-card-${index}`}
                >
                  <CardContent className="p-8">
                    <div className={`w-16 h-16 bg-${item.color}/10 rounded-xl flex items-center justify-center mb-6`}>
                      <item.icon className={`w-8 h-8 text-${item.color}`} />
                    </div>
                    <h3 className="text-2xl font-poppins font-bold text-navy mb-4">{item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
