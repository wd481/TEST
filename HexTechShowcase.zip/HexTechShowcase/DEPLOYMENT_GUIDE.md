
# Complete AWS EC2 Ubuntu 22.04 Deployment Guide

## Prerequisites
- AWS EC2 instance running Ubuntu 22.04
- SSH access to the instance
- Domain name (optional but recommended)

## Step 1: Connect to Your EC2 Instance
```bash
ssh -i your-key.pem ubuntu@your-ec2-public-ip
```

## Step 2: Update System and Install Dependencies
```bash
# Make install script executable
chmod +x install.sh

# Run installation script
./install.sh
```

## Step 3: Setup PostgreSQL Database
```bash
# Switch to postgres user and create database
sudo -u postgres psql -f database-setup.sql

# Verify database creation
sudo -u postgres psql -l
```

## Step 4: Configure Environment Variables
```bash
# Edit the production environment file
nano .env.production

# Ensure these variables are set:
NODE_ENV=production
DATABASE_URL=postgresql://portfolio_user:your_password@localhost:5432/portfolio_db
PORT=5000
```

## Step 5: Make Deployment Script Executable
```bash
chmod +x deploy.sh
```

## Step 6: Run Deployment
```bash
./deploy.sh
```

## Step 7: Configure Nginx
```bash
# Copy Nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/portfolio

# Enable the site
sudo ln -s /etc/nginx/sites-available/portfolio /etc/nginx/sites-enabled/

# Remove default site
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t

# If test passes, restart Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

## Step 8: Configure Firewall
```bash
# Configure UFW firewall
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable

# Check status
sudo ufw status
```

## Step 9: Verify Deployment
```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs portfolio-api

# Check if API is responding
curl http://localhost:5000/api/health

# Check Nginx status
sudo systemctl status nginx

# Test frontend (replace with your domain or IP)
curl http://your-domain-or-ip
```

## Step 10: Setup SSL (Optional but Recommended)
```bash
# Install SSL certificate (replace with your domain)
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

## Troubleshooting Commands

### Check Build Issues
```bash
# Check Node.js version
node --version
npm --version

# Check build locally
npm run build

# Check if dist folder exists
ls -la dist/
```

### Check PM2 Issues
```bash
# View detailed PM2 logs
pm2 logs portfolio-api --lines 50

# Restart application
pm2 restart portfolio-api

# Delete and recreate PM2 process
pm2 delete portfolio-api
pm2 start ecosystem.config.js
```

### Check Nginx Issues
```bash
# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Check Nginx access logs
sudo tail -f /var/log/nginx/access.log

# Test Nginx configuration
sudo nginx -t
```

### Check Database Issues
```bash
# Connect to database
sudo -u postgres psql -d portfolio_db

# Check if user can connect
psql -U portfolio_user -d portfolio_db -h localhost
```

### Check Port Issues
```bash
# Check what's running on port 5000
sudo netstat -tlnp | grep :5000

# Check if API port is accessible
curl http://localhost:5000/api/health
```

## Common Issues and Solutions

### Issue: "vite: not found"
**Solution**: This is now fixed in the updated deploy.sh script by installing all dependencies first.

### Issue: "Permission denied"
**Solution**: 
```bash
sudo chown -R $USER:$USER /var/www/portfolio
chmod +x deploy.sh
```

### Issue: "Database connection failed"
**Solution**: Check PostgreSQL is running and environment variables are correct:
```bash
sudo systemctl status postgresql
sudo systemctl start postgresql
```

### Issue: "PM2 process not starting"
**Solution**: Check the ecosystem.config.js and ensure the script path exists:
```bash
ls -la /var/www/portfolio/dist/index.js
```

### Issue: "502 Bad Gateway"
**Solution**: Check if the backend is running on port 5000:
```bash
pm2 status
curl http://localhost:5000/api/health
```

## Maintenance Commands

### Update Application
```bash
# Pull latest changes
git pull origin main

# Run deployment script
./deploy.sh
```

### Monitor Resources
```bash
# Check system resources
htop

# Check disk space
df -h

# Check memory usage
free -h
```

### Backup Database
```bash
# Create backup
pg_dump -U portfolio_user -h localhost portfolio_db > backup_$(date +%Y%m%d_%H%M%S).sql
```

### View Logs
```bash
# Application logs
pm2 logs portfolio-api

# System logs
sudo journalctl -u nginx -f

# Check all running processes
ps aux | grep node
```
