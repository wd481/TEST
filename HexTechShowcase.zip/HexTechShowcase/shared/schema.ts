
import { z } from "zod";

// Blog post schema
export const insertBlogPostSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  excerpt: z.string().optional(),
  isPublished: z.boolean().default(false),
  tags: z.array(z.string()).optional(),
  metadata: z.record(z.any()).optional(),
});

export const blogPostSchema = insertBlogPostSchema.extend({
  id: z.string(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export type BlogPost = z.infer<typeof blogPostSchema>;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;

// Portfolio content schema
export const insertPortfolioContentSchema = z.object({
  id: z.string(),
  section: z.string().min(1, "Section is required"),
  contentType: z.string().min(1, "Content type is required"),
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  metadata: z.record(z.any()).optional(),
  order: z.number().default(0),
  isActive: z.boolean().default(true),
});

export const portfolioContentSchema = insertPortfolioContentSchema.extend({
  createdAt: z.date(),
  updatedAt: z.date(),
});

export type PortfolioContent = z.infer<typeof portfolioContentSchema>;
export type InsertPortfolioContent = z.infer<typeof insertPortfolioContentSchema>;

// Timeline event schema for entrepreneurship section
export const timelineEventSchema = z.object({
  year: z.string(),
  title: z.string(),
  description: z.string(),
  icon: z.string(),
  achievements: z.array(z.string()),
});

export type TimelineEvent = z.infer<typeof timelineEventSchema>;

// Skills category schema for professional section
export const skillsCategorySchema = z.object({
  name: z.string(),
  skills: z.array(z.string()),
});

export type SkillsCategory = z.infer<typeof skillsCategorySchema>;

// Hero metadata schema for home section
export const heroMetadataSchema = z.object({
  subtitle: z.string(),
  ctaText: z.string(),
  backgroundImage: z.string().optional(),
});

export type HeroMetadata = z.infer<typeof heroMetadataSchema>;
