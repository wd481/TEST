# AWS EC2 Deployment Guide - K Sai Kiran Portfolio

## Prerequisites
- AWS Account with EC2 access
- Domain name (optional, can use EC2 public IP)
- SSH key pair for EC2 access

## Step 1: Launch EC2 Instance

### Instance Configuration:
- **AMI**: Ubuntu Server 22.04 LTS (Free tier eligible)
- **Instance Type**: t3.micro (1 vCPU, 1GB RAM) or t3.small for better performance
- **Key Pair**: Create new or use existing SSH key
- **Security Group**: Configure as follows:

```
Inbound Rules:
- SSH (22): Your IP only
- HTTP (80): 0.0.0.0/0
- HTTPS (443): 0.0.0.0/0
- Custom TCP (3000): 0.0.0.0/0 (for development, restrict later)
- Custom TCP (5000): 0.0.0.0/0 (for API, restrict later)
```

### Storage:
- 20GB GP3 (sufficient for your application)

## Step 2: Connect to EC2 Instance

```bash
# Replace with your key file and EC2 public IP
ssh -i your-key.pem ubuntu@your-ec2-ip
```

## Step 3: Update System & Install Dependencies

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x (LTS)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version

# Install additional tools
sudo apt install -y git nginx certbot python3-certbot-nginx unzip

# Install PM2 for process management
sudo npm install -g pm2

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib
```

## Step 4: Configure PostgreSQL Database

```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL shell:
CREATE DATABASE portfolio_db;
CREATE USER portfolio_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE portfolio_db TO portfolio_user;
ALTER DATABASE portfolio_db OWNER TO portfolio_user;
\q

# Configure PostgreSQL for remote connections (optional)
sudo nano /etc/postgresql/14/main/postgresql.conf
# Uncomment and modify: listen_addresses = 'localhost'

sudo nano /etc/postgresql/14/main/pg_hba.conf
# Add: local   portfolio_db   portfolio_user   md5

# Restart PostgreSQL
sudo systemctl restart postgresql
```

## Step 5: Upload and Setup Your Application

```bash
# Create application directory
sudo mkdir -p /var/www/portfolio
sudo chown -R ubuntu:ubuntu /var/www/portfolio
cd /var/www/portfolio

# Upload your ZIP file using SCP from your local machine:
# scp -i your-key.pem portfolio.zip ubuntu@your-ec2-ip:/var/www/portfolio/

# Extract files
unzip portfolio.zip
rm portfolio.zip

# Install dependencies
npm install

# Create production environment file
nano .env.production
```

### Environment Variables (.env.production):
```env
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://portfolio_user:your_secure_password@localhost:5432/portfolio_db
VITE_API_URL=http://your-domain.com/api
# Add any other required environment variables
```

## Step 6: Build and Start Application

```bash
# Build the frontend
npm run build

# Run database migrations (if applicable)
# npm run db:migrate

# Start application with PM2
pm2 start server/index.ts --name "portfolio-api" --interpreter="node" --interpreter-args="-r tsx/cjs"

# Start PM2 on system startup
pm2 startup
pm2 save

# Check PM2 status
pm2 status
pm2 logs portfolio-api
```

## Step 7: Configure Nginx Reverse Proxy

```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/portfolio
```

### Nginx Configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Serve static files (React build)
    location / {
        root /var/www/portfolio/client/dist;
        try_files $uri $uri/ /index.html;
        
        # Cache static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
    
    # Proxy API requests to Express server
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
}
```

### Enable Nginx Configuration:
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/portfolio /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

## Step 8: Configure SSL with Let's Encrypt (Optional but Recommended)

```bash
# Install SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal test
sudo certbot renew --dry-run
```

## Step 9: Configure Firewall

```bash
# Configure UFW firewall
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable

# Check status
sudo ufw status
```

## Step 10: Monitor and Maintain

### Useful Commands:
```bash
# Check application status
pm2 status
pm2 logs portfolio-api

# Restart application
pm2 restart portfolio-api

# Check Nginx status
sudo systemctl status nginx

# Check database
sudo -u postgres psql -d portfolio_db -c "SELECT version();"

# View system resources
htop
df -h

# Check application logs
sudo journalctl -u nginx
tail -f /var/log/nginx/error.log
```

## Step 11: Domain Configuration

### If Using Custom Domain:
1. Point your domain's A record to EC2 public IP
2. Update VITE_API_URL in .env.production
3. Rebuild frontend: `npm run build`
4. Update Nginx server_name
5. Restart services

### Using Elastic IP (Recommended):
1. Allocate Elastic IP in AWS Console
2. Associate with your EC2 instance
3. Update DNS records to point to Elastic IP

## Security Best Practices

1. **Regular Updates**:
   ```bash
   sudo apt update && sudo apt upgrade
   npm audit fix
   ```

2. **Backup Database**:
   ```bash
   pg_dump -U portfolio_user -h localhost portfolio_db > backup.sql
   ```

3. **Monitor Resources**:
   - Set up CloudWatch monitoring
   - Configure log rotation
   - Monitor disk space

4. **Restrict Access**:
   - Use security groups to limit access
   - Consider VPN for SSH access
   - Regular security audits

## Troubleshooting

### Common Issues:
- **Port conflicts**: Check if ports are already in use
- **Permission errors**: Ensure correct ownership of files
- **Database connection**: Verify PostgreSQL is running
- **Build errors**: Check Node.js version compatibility
- **SSL issues**: Verify domain DNS propagation

### Debug Commands:
```bash
# Check port usage
sudo netstat -tlnp | grep :5000

# Check process status
ps aux | grep node

# Test database connection
psql -U portfolio_user -d portfolio_db -h localhost
```

## Performance Optimization

1. **Enable Gzip in Nginx**:
   ```nginx
   gzip on;
   gzip_vary on;
   gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
   ```

2. **Database Optimization**:
   ```bash
   # Tune PostgreSQL for your instance size
   sudo nano /etc/postgresql/14/main/postgresql.conf
   ```

3. **PM2 Cluster Mode** (for better performance):
   ```bash
   pm2 start server/index.ts --name "portfolio-api" -i max
   ```

Your portfolio website will be fully deployed and accessible via your domain or EC2 public IP address!